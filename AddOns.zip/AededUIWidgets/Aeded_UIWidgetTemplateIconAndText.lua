local function GetIconAndTextVisInfoData(widgetID)
	local widgetInfo = C_UIWidgetManager.GetIconAndTextWidgetVisualizationInfo(widgetID);
	if widgetInfo and widgetInfo.state > Enum.IconAndTextWidgetState.Hidden then
		return widgetInfo;
	end
end

AededUIWidgetManager:RegisterWidgetVisTypeTemplate(Enum.UIWidgetVisualizationType.IconAndText, {frameType = "FRAME", frameTemplate = "AededUIWidgetTemplateIconAndText"}, GetIconAndTextVisInfoData);

AededUIWidgetTemplateIconAndTextMixin = CreateFromMixins(AededUIWidgetBaseTemplateMixin);

local textureKitRegions = {
	["Icon"] = "%s-icon",
	["DynamicIconTexture"] = "%s-dynamicIcon",
	["FlashTexture"] = "%s-flash",
}

function AededUIWidgetTemplateIconAndTextMixin:OnAcquired(widgetInfo)
	self.Text:ClearAllPoints();

	if self.Icon:IsShown() then
		self.alignWidth = self.Icon:GetWidth()- 12 + self.Text:GetStringWidth();
		self.Text:SetPoint("TOPLEFT", self.Icon, "TOPRIGHT", -12, -6);
	else
		self.alignWidth = self.Text:GetStringWidth();
		self.Text:SetPoint("TOPLEFT", self.Icon, "TOPLEFT", 0, -6);
	end

	self:SetWidth(self.alignWidth);
end

function AededUIWidgetTemplateIconAndTextMixin:Setup(widgetInfo)
	AededUIWidgetBaseTemplateMixin.Setup(self, widgetInfo);
	SetupTextureKits(widgetInfo.textureKitID, self, textureKitRegions, true);
	local widgetText = widgetInfo.text
	
	--print(widgetText)
	if widgetText and string.find(widgetText, "Time Remaining") then 

		widgetText = string.sub(widgetText, 18) 

	elseif widgetText and string.find(widgetText, "Towers Controlled") then 

		widgetText = string.sub(widgetText, 19)
		
	elseif widgetText and string.find(widgetText, "Victory Points:") then 
	--print("Ss")

		widgetText = string.gsub(widgetText, "Bases: " , "")
		widgetText = string.gsub(widgetText, " Victory Points: " , "| ")
		widgetText = string.gsub(widgetText, "/2000" , " ")

	elseif widgetText and string.find(widgetText, "Controlled") then 
	
		widgetText = string.sub(widgetText, 13) 

	elseif widgetText and string.find(widgetText, "Beacon") then 

		widgetText = string.gsub(widgetText, " Beacon", " ")

	elseif widgetText and string.find(widgetText, "Guards Remaining:") then 

		widgetText = string.gsub(widgetText, "Guards Remaining: ", "")

	elseif widgetText and string.find(widgetText, "Reinforcements") then 
	
		widgetText = string.sub(widgetText, 16)

	elseif widgetText and string.find(widgetText, "Bases:") then 

		widgetText = string.gsub(widgetText, "Bases: " , "")
		widgetText = string.gsub(widgetText, " Resources: " , "| ")
		widgetText = string.gsub(widgetText, "/2000" , "")

	elseif widgetText and string.find(widgetText, "Players") then 

		if  string.find(widgetText, "Gold") then

			widgetText = string.sub(widgetText, 11)
			widgetText = string.gsub(widgetText, " Remaining" , "")
		
		elseif  string.find(widgetText, "Purple") then

			widgetText = string.sub(widgetText, 14)
			widgetText = string.gsub(widgetText, " Remaining" , "")

		end
	end
	
	
	self.Text:SetText(widgetText);
	self:SetTooltip(widgetInfo.tooltip);
	self.DynamicIconButton:SetTooltip(widgetInfo.dynamicTooltip);

	if ( widgetInfo.state == Enum.IconAndTextWidgetState.ShownWithDynamicIconFlashing ) then
		UIFrameFlash(self.Flash, 0.5, 0.5, -1);
		self.DynamicIconButton:Show();
	elseif ( widgetInfo.state == Enum.IconAndTextWidgetState.ShownWithDynamicIconNotFlashing ) then
		UIFrameFlashStop(self.Flash);
		self.DynamicIconButton:Show();
	else
		UIFrameFlashStop(self.Flash);
		self.DynamicIconButton:Hide();
	end
end

function AededUIWidgetTemplateIconAndTextMixin:OnLoad()
	self.DynamicIconTexture = self.DynamicIconButton.Icon;
	self.FlashTexture = self.Flash.Texture;
end
