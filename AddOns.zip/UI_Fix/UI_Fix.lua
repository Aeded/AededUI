-- UI Fix
hooksecurefunc("ActionButton_ShowGrid", function(Button)
   if not Button then
      Button = this
   end
   _G[Button:GetName().."NormalTexture"]:SetVertexColor(1, 1, 1, 1)
end)



----------------------------------------------------------------------------------------------------
--random
----------------------------------------------------------------------------------------------------
ExhaustionTick:Hide()
ExhaustionTickNormal:Hide()
ExhaustionTickHighlight:Hide()

MinimapZoomIn:Hide()
MinimapZoomOut:Hide()
MinimapZoneText:Hide()
MinimapZoneTextButton:Hide()
MinimapBorderTop:Hide()
MinimapToggleButton:Hide()
MiniMapWorldMapButton:Hide()
GameTimeFrame:Hide()

MinimapCluster:SetScale(0.95)
MinimapCluster:ClearAllPoints()
MinimapCluster:SetPoint("TOPRIGHT", "UIParent", "TOPRIGHT", 10, -20);


-----------------------------------------------------------------------------------------------------
--Error messages
-----------------------------------------------------------------------------------------------------


local event = CreateFrame"Frame"
local dummy = function() end


UIErrorsFrame:UnregisterEvent"UI_ERROR_MESSAGE"
event.UI_ERROR_MESSAGE = function(self, event, error)
	if(not stuff[error]) then
		UIErrorsFrame:AddMessage(error, 1, .1, .1)
	end
end
	
event:RegisterEvent"UI_ERROR_MESSAGE"




----------------------------------------------------------------------------------------------------
--Frames scale
----------------------------------------------------------------------------------------------------
--SetCVar("UIScale", 0.675)




WorldMapFrame.ScrollContainer.GetCursorPosition = function(f)
   local x,y = MapCanvasScrollControllerMixin.GetCursorPosition(f);
   local s = WorldMapFrame:GetScale();
   return x/s, y/s;
end

WorldMapFrame:SetScale(0.8)
WorldMapFrame.BlackoutFrame.Blackout:SetAlpha(0)
WorldMapFrame.BlackoutFrame:EnableMouse(false)

WorldMapFrame:SetMovable(true)
WorldMapFrame:EnableMouse(true)
WorldMapFrame:RegisterForDrag("LeftButton")
WorldMapFrame:SetScript("OnDragStart", WorldMapFrame.StartMoving)
WorldMapFrame:SetScript("OnDragStop", WorldMapFrame.StopMovingOrSizing)



ComboFrame:SetScale(1.3);
ComboFrame:ClearAllPoints();
ComboFrame:SetPoint("TOPRIGHT", "AededUITargetFrame", "TOPRIGHT", -46.5, -7.5);



--beter way with XML
for i=1, MAX_PARTY_MEMBERS do

	local frame = _G["AededUIPartyMemberFrame"..i]
	local frameName = _G["AededUIPartyMemberFrame"..i.."Name"]
	local petFrame = _G["AededUIPartyMemberFrame"..i.."PetFrame"]
	if ( i < 3 ) then
		frame:SetScale(1.5);
		petFrame:SetScale(0.85);
		frameName:SetFont("Fonts\\FRIZQT__.TTF", 8.3)
	else
		frame:SetScale(1);
		frameName:SetFont("Fonts\\FRIZQT__.TTF", 10)
	end
	
end

local hideTable = {
	PartyMemberFrame1,
	PartyMemberFrame2,
	PartyMemberFrame3,
	PartyMemberFrame4,
	CastingBarFrame,
	UIWidgetTopCenterContainerFrame,
	PlayerFrame,
	PetFrame,
	TargetFrame,
	FocusFrame,
	TotemFrame,
	
}
local BlizzardHide = CreateFrame("Frame")
BlizzardHide:Hide()
BlizzardHide:SetAllPoints()
for _,v in ipairs(hideTable) do
    v:SetParent(BlizzardHide)
end

hooksecurefunc("FCF_StartAlertFlash", function(self) FCF_StopAlertFlash(self) end)



