
local function GetGradientHealth(percent)

	local minHpColor = { r = 1.0, g = 0.0, b = 0.0 }
	local midHpColor = { r = 1.0, g = 1.0, b = 0.0 }
	local maxHpColor = { r = 0.0, g = 1.0, b = 0.0 }

	local color1
	local color2
	
	if percent <= 0.5 then
	
		percent = percent * 2
		color1 = minHpColor
		color2 = midHpColor
		
	else
	
		percent = percent * 2 - 1
		color1 = midHpColor
		color2 = maxHpColor
		
	end
	return color1.r + (color2.r-color1.r)*percent, color1.g + (color2.g-color1.g)*percent, color1.b + (color2.b-color1.b)*percent	
end

function AededUIHealthBar_OnValueChanged(self, value)
	if ( not value ) then
		return;
	end
	local min, max = self:GetMinMaxValues();
	if ( (value < min) or (value > max) ) then
		return;
	end
	if ( (max - min) > 0 ) then
		value = (value - min) / (max - min);
	else
		value = 0;
	end
	--local valuePercent = (currValue / valueMax)

	if ( not self.lockColor ) then
		self:SetStatusBarColor(GetGradientHealth(value))
	end
end
