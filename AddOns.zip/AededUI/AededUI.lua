AededUI_ActiveTrinketTimers = {}
AededUI_ActiveParty1Timers = {}
AededUI_ActiveParty2Timers = {}
local CooldownsUpdate = 0
local TimeSinceLastUpdate = 0

function AededUI_Reoriginate(array)
	for i = 1, #array do
		array[i].frame:SetPoint("TOPLEFT", array[i].name.."Point"..i ,"TOPLEFT", 0, 0)
	end
end

function AededUICooldowns_OnUpdate(self, elapsed)

	CooldownsUpdate = CooldownsUpdate + elapsed
	
	if CooldownsUpdate >= 1 then
	--print("ss")
		for i = 1, 10 do
			if ( i <= #AededUI_ActiveTrinketTimers and GetTime() >= AededUI_ActiveTrinketTimers[i].times ) then
				AededUI_ActiveTrinketTimers[i].frame:Hide()
				table.remove(AededUI_ActiveTrinketTimers, i)
			end	
		end
		
		for i, _ in pairs(AededUI_ActiveParty1Timers) do

			if ( i <= #AededUI_ActiveParty1Timers and GetTime() >= AededUI_ActiveParty1Timers[i].times ) then
				AededUI_ActiveParty1Timers[i].frame:Hide()
				--print(AededUI_ActiveParty1Timers[i].frame:GetName(), "Should be hidden")
				table.remove(AededUI_ActiveParty1Timers, i)
				AededUI_Reoriginate(AededUI_ActiveParty1Timers)
			end	
		end
		
		for i, _ in pairs(AededUI_ActiveParty2Timers) do
			if ( i <= #AededUI_ActiveParty2Timers and GetTime() >= AededUI_ActiveParty2Timers[i].times ) then
				AededUI_ActiveParty2Timers[i].frame:Hide()
				--print(AededUI_ActiveParty2Timers[i].frame:GetName(), "Should be hidden")
				table.remove(AededUI_ActiveParty2Timers, i)
				AededUI_Reoriginate(AededUI_ActiveParty2Timers)
			end	
		end
		
		CooldownsUpdate = 0
	end
end

AededUICooldowns = CreateFrame("Frame")
AededUICooldowns:SetScript("OnUpdate", AededUICooldowns_OnUpdate)


function AededUI_OnUpdate(self, elapsed)

	TimeSinceLastUpdate = TimeSinceLastUpdate + elapsed

	if TimeSinceLastUpdate >= 0.05 then
		AededUIUnitPopup_OnUpdate(elapsed);
		TimeSinceLastUpdate = 0
	end
end

AededUIParent = CreateFrame("Frame")
AededUIParent:SetScript("OnUpdate", AededUI_OnUpdate)



local AededUI = CreateFrame("Frame")
AededUI:RegisterEvent("PLAYER_LOGIN")
AededUI:RegisterEvent("PLAYER_TOTEM_UPDATE")
AededUI:RegisterEvent("UNIT_AURA")


local previous_Totem = nil

local function eventHandler(self, event, arg1)
		

		if ( event == "UNIT_AURA" and arg1 == "player") then
			
			local buffs, i = {}, 1;
			local buff = UnitBuff("player", i);
			while buff do
				if buff == "Elemental Mastery" then
				
				end
				i = i + 1;
				buff = UnitBuff("player", i);
			end;
		
		elseif ( event == "PLAYER_TOTEM_UPDATE" and arg1 == 2 ) then
	
			local _, totemName, _, duration = GetTotemInfo(arg1)

			if duration ~= 0  then
			
				previous_Totem = totemName
				
			end
			
			if (duration == 0 and previous_Totem == "Tremor Totem") then
			
				PlaySoundFile("Interface\\AddOns\\UI_Fix\\Sounds\\BikeHorn.ogg")
				
			end
			return;
        elseif ( event == "PLAYER_LOGIN" )then
      	
			if LoadAddOn("Blizzard_CombatText") then
                ENTERING_COMBAT = "+Combat"
                LEAVING_COMBAT = "-Combat"
                CombatText:SetScale(.85)
                COMBAT_TEXT_TYPE_INFO["ENTERING_COMBAT"].r = 1
                COMBAT_TEXT_TYPE_INFO["ENTERING_COMBAT"].g = 0
                COMBAT_TEXT_TYPE_INFO["ENTERING_COMBAT"].b = 1
                COMBAT_TEXT_TYPE_INFO["LEAVING_COMBAT"].r = 1
                COMBAT_TEXT_TYPE_INFO["LEAVING_COMBAT"].g = 0
                COMBAT_TEXT_TYPE_INFO["LEAVING_COMBAT"].b = 1
			end
		end
end

AededUI:SetScript("OnEvent", eventHandler)

--------------------------------------------------------------------------------------------------------------------------------
			

for i=1,4 do select(2, _G["TotemFrameTotem"..i]:GetChildren()):GetRegions():SetVertexColor(.3,.3,.3) 

end

for i, v in pairs({BonusActionBarTexture0, BonusActionBarTexture1, BonusActionBarFrameTexture0, 
		BonusActionBarFrameTexture1, BonusActionBarFrameTexture2, BonusActionBarFrameTexture3,
        	BonusActionBarFrameTexture4, MainMenuBarTexture0, MainMenuBarTexture1, 
		MainMenuBarTexture2, MainMenuBarTexture3, MainMenuMaxLevelBar0, MainMenuMaxLevelBar1, 
		MainMenuMaxLevelBar2, MainMenuMaxLevelBar3,SlidingActionBarTexture0, SlidingActionBarTexture1}) do 
	v:SetVertexColor(.65, .65, .65)
end


for i, v in pairs({PlayerFrameTexture, TargetFrameTexture, PetFrameTexture, 
	PartyMemberFrame1Texture, PartyMemberFrame2Texture, PartyMemberFrame3Texture, 
	PartyMemberFrame4Texture, PartyMemberFrame1PetFrameTexture, 
	PartyMemberFrame2PetFrameTexture, PartyMemberFrame3PetFrameTexture, PartyMemberFrame4PetFrameTexture, FocusFrameTexture,
	TargetofTargetTexture, TargetofFocusTexture}) do 
	v:SetVertexColor(.8, .8, .8)
end

for i, v in pairs({MainMenuXPBarTexture0, MainMenuXPBarTexture1,
	MainMenuXPBarTexture2, MainMenuXPBarTexture3, 
	ReputationWatchBarTexture0, ReputationWatchBarTexture1, 
	ReputationWatchBarTexture2, ReputationWatchBarTexture3,
	ReputationXPBarTexture0, ReputationXPBarTexture1,
	ReputationXPBarTexture2, ReputationXPBarTexture3}) do 
	v:SetVertexColor(.2, .2, .2)
end

for i, v in pairs({MinimapBorder, MiniMapTrackingBorder,
	MiniMapLFGFrameBorder, MiniMapBattlefieldBorder,
        MiniMapMailBorder, MinimapBorderTop}) do 
        v:SetVertexColor(.3, .3, .3)
end

for i, v in pairs({CastingBarFrameBorder, 
	MirrorTimer1Border, MirrorTimer2Border, MirrorTimer3Border, FocusFrameSpellBarBorder, 
	TargetFrameSpellBarBorder}) do 
        v:SetVertexColor(.3, .3, .3)
end

for i, v in pairs({PossessBackground1, PossessBackground2, PossesBarLeft, 
	PossesBarMiddle, PossesBarRight, 
	ShapeshiftBarLeft, ShapeshiftBarMiddle, 
	ShapeshiftBarRight}) do 
	v:SetVertexColor(.8, .8, .8)
end


for i, v in pairs({MainMenuBarLeftEndCap, MainMenuBarRightEndCap}) do
	v:SetVertexColor(.9, .9, .9)
end

--------------------------------------------------------------------------------------------------------------------------------