AededUI_MAX_PARTY_MEMBERS = 4;
AededUI_MAX_PARTY_BUFFS = 4;
AededUI_MAX_PARTY_DEBUFFS = 4;

local cooldownPartyFrame = {

	GENERAL = {
	
		--Spells
		
        ["Stoneform"] = {duration = 180, reset = nil},
		["Blood Fury"] = {duration = 120, reset = nil},
		["Will of the Forsaken"] = {duration = 120, reset = nil},
		["War Stomp"] = {duration = 120, reset = nil},
		["Escape Artist"] = {duration = 105, reset = nil},
    },

    DRUID = {
		["Barkskin"] = {duration = 60, reset = nil},
		["Bash"] = {duration = 60, reset = nil},
		["Feral Charge"] = {duration = 15, reset = nil},
		["Nature's Swiftness"] = {duration = 180, reset = nil},
		["Innervate"] = {duration = 360, reset = nil},
        
    },
	
    HUNTER = {
		["Scatter Shot"] = {duration = 30, reset = nil},
		["Silence Shot"] = {duration = 20, reset = nil},
		["Ice Trap"] = {duration = 30, reset = true},
		["Frost Trap"] = {duration = 30, reset = true},
		["Snake Trap"] = {duration = 30, reset = true},
		["Immolation Trap"] = {duration = 30, reset = true},
		["Explosion Trap"] = {duration = 30, reset = true},
		["Intimidation"] = {duration = 60, reset = nil},
		["Wyvern Sting"] = {duration = 120, reset = true},
		["Readiness"] = {duration = 300, reset = nil},
		["The Beast Within"] = {duration = 120, reset = nil}, 
		["Deterrence"] = {duration = 300, reset = true},
    },
	
    MAGE = {
		["Counterspell"] = {duration = 24, reset = nil},
		["Ice Block"] = {duration = 240, reset = true},
		["Summon Water Elemental"] = {duration = 180, reset = true},
		["Cold Snap"] = {duration = 180, reset = nil},
		["Presence of Mind"] = {duration = 180, reset = nil},
		["Combustion"] = {duration = 180, reset = nil},
		["Arcane Power"] = {duration = 180, reset = nil},
		["Icy Veins"] = {duration = 180, reset = true},
		--["Frost Nova"] = {duration = 24, reset = true},
		--["Cone of Cold"] = {duration = 12, reset = true},
        --["Ice Barrier"] = {duration = 24, reset = true},
    },
	
    PALADIN = {	
		["Blessing of Protection"] = {duration = 180, reset = nil},
        ["Blessing of Freedom"] = {duration = 25, reset = nil},
		["Divine Shield"] = {duration = 300, reset = nil},
		["Hammer of Justice"] = {duration = 60, reset = nil},
    },
	
    PRIEST = {
		["Silence"] = {duration = 45, reset = nil},
		["Power Infusion"] = {duration = 180, reset = nil},
		["Psychic Scream"] = {duration = 27, reset = nil},
		["Prayer of Mending"] = {duration = 10, reset = nil},
		["Pain Suppression"] = {duration = 120, reset = nil},
        ["Shadow Word: Death"] = {duration = 12, reset = nil},
		["Shadowfiend"] = {duration = 300, reset = nil},
		["Chastise"] = {duration = 300, reset = nil},
		--["Power Infusion"] = {duration = 180, reset = nil},
    },
	
	
	ROGUE = {
		["Blind"] = {duration = 90, reset = nil},
		["Evasion"] = {duration = 300, reset = true},
		--["Sprint"] = {duration = 300, reset = true},
		["Vanish"] = {duration = 180, reset = true},
		["Cloak of Shadows"] = {duration = 180, reset = nil},
		["Kick"] = {duration = 10, reset = nil},
		["Shadowstep"] = {duration = 30, reset = true},
		["Preparation"] = {duration = 600, reset = nil},
		["Cold Blood"] = {duration = 180, reset = true},
		--["Premeditation"] = {duration = 120, reset = true},
		["Adrenaline Rush"] = {duration = 300, reset = nil},
        
    },
	
	SHAMAN = {
		["Mana Tide Totem"] = {duration = 300, reset = nil},
		["Shamanistic Rage"] = {duration = 120, reset = nil},
		["Frost Shock"] = {duration = 6, reset = nil},
		["Flame Shock"] = {duration = 6, reset = nil},
		["Earth Shock"] = {duration = 6, reset = nil},
        ["Grounding Totem"] = {duration = 15, reset = nil},
		["Nature's Swiftness"] = {duration = 180, reset = nil},
		["Elemental Mastery"] = {duration = 180, reset = nil},
		["Bloodlust"] = {duration = 600, reset = nil},
		["Heroism"] = {duration = 600, reset = nil},
    },
	
	WARLOCK = {
		["Spell Lock"] = {duration = 24, reset = true},
		["Fel Domination"] = {duration = 900, reset = nil},
		["Shadowfury"] = {duration = 20, reset = nil},
		["Death Coil"] = {duration = 180, reset = nil},
		["Intercept"] = {duration = 30, reset = true},
        
    },
	
	WARRIOR = {
		["Intercept"] = {duration = 15, reset = nil},
		["Spell Reflection"] = {duration = 10, reset = nil},
		["Concussion Blow"] = {duration = 45, reset = nil},
		["Death Wish"] = {duration = 180, reset = nil},
		["Pummel"] = {duration = 10, reset = nil},
		["Shield Bash"] = {duration = 12, reset = nil},
		["Disarm"] = {duration = 60, reset = nil},
		["Intimidating Shout"] = {duration = 180, reset = nil},
        
    }
}

function AededUIHidePartyFrame()
	for i=1, AededUI_MAX_PARTY_MEMBERS, 1 do
		if not InCombatLockdown() then
			_G["AededUIPartyMemberFrame"..i]:Hide();
		end
	end
end

function AededUIShowPartyFrame()
	for i=1, AededUI_MAX_PARTY_MEMBERS, 1 do
		if ( UnitExists("party"..i) and not InCombatLockdown()) then
			_G["AededUIPartyMemberFrame"..i]:Show();
		end
	end
end

function AededUIPartyMemberFrame_UpdateArt(self)
	local unit = "party"..self:GetID();
	AededUIPartyMemberFrame_ToPlayerArt(self);
end

function AededUIPartyMemberFrame_ToPlayerArt(self)
	self.state = "player";
	local prefix = self:GetName();
	_G[prefix.."VehicleTexture"]:Hide();
	_G[prefix.."Texture"]:Show();
	_G[prefix.."Portrait"]:SetPoint("TOPLEFT", 7, -6);
	_G[prefix.."LeaderIcon"]:SetPoint("TOPLEFT", 0, 0);
	_G[prefix.."Disconnect"]:SetPoint("LEFT", -7, -1);

	self.overrideName = nil;

	AededUIUnitFrame_SetUnit(self, "party"..self:GetID(), _G[prefix.."HealthBar"], _G[prefix.."ManaBar"]);
	if ( self:GetID() < 3 ) then
		AededUIUnitFrame_SetUnit(_G[prefix.."PetFrame"], "partypet"..self:GetID(), _G[prefix.."PetFrameHealthBar"], nil);
	end
	AededUIPartyMemberFrame_UpdateMember(self);

	AededUIUnitFrame_Update(self)
end

function AededUIPartyMemberFrame_ToVehicleArt(self, vehicleType)
	self.state = "vehicle";
	local prefix = self:GetName();
	_G[prefix.."Texture"]:Hide();
	if ( vehicleType == "Natural" ) then
		_G[prefix.."VehicleTexture"]:SetTexture("Interface\\Vehicles\\UI-Vehicles-PartyFrame-Organic");
	else
		_G[prefix.."VehicleTexture"]:SetTexture("Interface\\Vehicles\\UI-Vehicles-PartyFrame");
	end
	_G[prefix.."VehicleTexture"]:Show();
	_G[prefix.."Portrait"]:SetPoint("TOPLEFT", 4, -9);
	_G[prefix.."LeaderIcon"]:SetPoint("TOPLEFT", -3, 0);
	_G[prefix.."Disconnect"]:SetPoint("LEFT", -10, -1);

	self.overrideName = "party"..self:GetID();

	AededUIUnitFrame_SetUnit(self, "partypet"..self:GetID(), _G[prefix.."HealthBar"], _G[prefix.."ManaBar"]);
	AededUIUnitFrame_SetUnit(_G[prefix.."PetFrame"], "party"..self:GetID(), _G[prefix.."PetFrameHealthBar"], nil);
	AededUIPartyMemberFrame_UpdateMember(self);

	AededUIUnitFrame_Update(self)
	
end

function AededUIPartyMemberFrame_OnLoad (self)
	local id = self:GetID();
	self.debuffCountdown = 0;
	self.numDebuffs = 0;
	self.noTextPrefix = true;
	local prefix = "AededUIPartyMemberFrame"..id;
	_G[prefix.."HealthBar"].LeftText = _G[prefix.."HealthBarTextLeft"];
	_G[prefix.."HealthBar"].RightText = _G[prefix.."HealthBarTextRight"];
	_G[prefix.."ManaBar"].LeftText = _G[prefix.."ManaBarTextLeft"];
	_G[prefix.."ManaBar"].RightText = _G[prefix.."ManaBarTextRight"];

	AededUIUnitFrame_Initialize(self, "party"..id,  _G[prefix.."Name"], _G[prefix.."Portrait"],
		   _G[prefix.."HealthBar"], _G[prefix.."HealthBarText"],
		   _G[prefix.."ManaBar"], _G[prefix.."ManaBarText"],
		   nil, nil, nil, nil, nil, 
		   nil, nil, nil,
		   nil, nil, nil,
		   nil);
	AededUISetTextStatusBarTextZeroText(_G[prefix.."HealthBar"], DEAD);
	self.statusCounter = 0;
	self.statusSign = -1;
	self.unitHPPercent = 1;
	AededUIPartyMemberFrame_UpdateMember(self);
	AededUIPartyMemberFrame_UpdateLeader(self);
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	self:RegisterEvent("ARENA_COOLDOWNS_UPDATE");
	self:RegisterEvent("GROUP_ROSTER_UPDATE");
	self:RegisterEvent("UPDATE_ACTIVE_BATTLEFIELD");
	self:RegisterEvent("PARTY_LEADER_CHANGED");
	self:RegisterEvent("PARTY_LOOT_METHOD_CHANGED");
	self:RegisterEvent("VARIABLES_LOADED");
	self:RegisterEvent("READY_CHECK");
	self:RegisterEvent("READY_CHECK_CONFIRM");
	self:RegisterEvent("READY_CHECK_FINISHED");
	self:RegisterEvent("UNIT_CONNECTION");
	self:RegisterEvent("PARTY_MEMBER_ENABLE");
	self:RegisterEvent("PARTY_MEMBER_DISABLE");
	self:RegisterEvent("UNIT_PHASE");
	self:RegisterEvent("UNIT_FLAGS");
	self:RegisterEvent("UNIT_OTHER_PARTY_CHANGED");
	local id = self:GetID();
	self:RegisterUnitEvent("UNIT_AURA", "party"..id, "partypet"..id);
	self:RegisterUnitEvent("UNIT_PET",  "party"..id, "partypet"..id);
	local showmenu = function()
		ToggleDropDownMenu(1, nil, _G["AededUIPartyMemberFrame"..self:GetID().."DropDown"], self:GetName(), 47, 15);
	end
	SecureUnitButton_OnLoad(self, "party"..id, showmenu);

	AededUIPartyMemberFrame_UpdateArt(self);
end


function AededUIPartyMemberFrame_UpdateMember (self)
	
	local id = self:GetID();
	local unit = "party"..id;
	
	if ( UnitExists(unit) ) then
		AededUIUnitFrame_Update(self);
	end

	AededUIPartyMemberFrame_UpdatePet(self);
	AededUIRefreshPartyAuras(self, "party"..id, nil, nil);
	AededUIUnitFrame_LoseControl(self);
	AededUIPartyMemberFrame_UpdateReadyCheck(self);
	AededUIPartyMemberFrame_UpdateOnlineStatus(self);
	AededUIPartyMemberFrame_UpdateNotPresentIcon(self);

end

function AededUIPartyMemberFrame_UpdatePet (self, id)
	
	if ( not id ) then
		id = self:GetID();
	end
	
	if ( id > 2 ) then
		return
	end
	
	local frameName = _G["AededUIPartyMemberFrame"..id];
	local petFrame = _G["AededUIPartyMemberFrame"..id.."PetFrame"];
	
	AededUIPartyMemberFrame_RefreshPetDebuffs(self, id);
end

function AededUIPartyMemberFrame_UpdateLeader (self)
	local id = self:GetID();
	local leaderIcon = _G["AededUIPartyMemberFrame"..id.."LeaderIcon"];
	local guideIcon = _G["AededUIPartyMemberFrame"..id.."GuideIcon"];
	local masterIcon = _G["AededUIPartyMemberFrame"..id.."MasterIcon"];

	if( UnitIsGroupLeader("party"..id) ) then
		leaderIcon:Show();
		guideIcon:Hide();
	else
		guideIcon:Hide();
		leaderIcon:Hide();
	end

	local lootMethod, lootMaster = GetLootMethod();
	if ( lootMaster == id ) then
		masterIcon:Show();
	else
		masterIcon:Hide();
	end
end


function AededUIPartyMemberFrame_UpdateReadyCheck (self)
	local id = self:GetID();
	local partyID = "party"..id;

	local readyCheckFrame = _G["AededUIPartyMemberFrame"..id.."ReadyCheck"];
	local readyCheckStatus = GetReadyCheckStatus(partyID);
	if ( UnitName(partyID) and UnitIsConnected(partyID) and readyCheckStatus ) then
		if ( readyCheckStatus == "ready" ) then
			ReadyCheck_Confirm(readyCheckFrame, 1);
		elseif ( readyCheckStatus == "notready" ) then
			ReadyCheck_Confirm(readyCheckFrame, 0);
		else -- "waiting"
			ReadyCheck_Start(readyCheckFrame);
		end
	else
		readyCheckFrame:Hide();
	end
end

function AededUIPartyMemberFrame_UpdateNotPresentIcon(self)
	local id = self:GetID();
	local partyID = "party"..id;

	local inPhase = UnitInPhase(partyID);

	if ( UnitInOtherParty(partyID) ) then
		self:SetAlpha(0.6);
		self.notPresentIcon.texture:SetTexture("Interface\\LFGFrame\\LFG-Eye");
		self.notPresentIcon.texture:SetTexCoord(0.125, 0.25, 0.25, 0.5);
		self.notPresentIcon.Border:Show();
		self.notPresentIcon.tooltip = PARTY_IN_PUBLIC_GROUP_MESSAGE;
		self.notPresentIcon:Show();
	elseif ( (not inPhase) and UnitIsConnected(partyID) ) then
		self:SetAlpha(0.6);
		self.notPresentIcon.texture:SetTexture("Interface\\TargetingFrame\\UI-PhasingIcon");
		self.notPresentIcon.texture:SetTexCoord(0.15625, 0.84375, 0.15625, 0.84375);
		self.notPresentIcon.Border:Hide();
		self.notPresentIcon.tooltip = PARTY_PHASED_MESSAGE;
		self.notPresentIcon:Show();
	else
		self:SetAlpha(1);
		self.notPresentIcon:Hide();
	end


end

function AededUIPartyFrame_CreateSpellbar(self, event)
	local selfID = self:GetID()
	local spellbar = _G[self:GetName().."SpellBar"];

	--spellbar:SetFrameLevel(_G["AededUIPartyMemberFrame"..selfID.."TextureFrame"]:GetFrameLevel() - 1);
	self.spellbar = spellbar;
	self.auraRows = 0;
	
	spellbar:RegisterEvent("VARIABLES_LOADED");

	AededUICastingBarFrame_SetUnit(spellbar, self.unit, false, true);
	if ( event ) then
		spellbar.updateEvent = event;
		spellbar:RegisterEvent(event);
	end

	-- check to see if the castbar should be shown
	if ( selfID > 2 ) then
		spellbar.showCastbar = false
	end
end

local function AededUIResetCooldowns(self)
	local selfID = self:GetID()
	local parentName = self:GetName()
	local array = _G["AededUI_ActiveParty"..selfID.."Timers"]
	
	for i = 10, 1, -1 do
		if ( i <= #array and array[i].aReset ) then
			local prefix = parentName.."Ability"..i
			local frameName = _G[prefix]
			local frameCooldown = _G[prefix.."Cooldown"]
			frameCooldown:Clear()
			frameName:Hide()
			table.remove(array, i)
			i = 1
		end
	end
	AededUI_Reoriginate(array)
end

local function AededUIResetAllTrinkets(self)
	local frameName = self:GetName().."PvPTrinket"
	local trinketFrame = _G[frameName]
	local trinketIcon = _G[frameName.."Icon"]
	local trinketCooldown = _G[frameName.."Cooldown"]
	local array = _G["AededUI_ActiveTrinketTimers"]
	
	trinketCooldown:Clear()
	trinketFrame:Hide()
	for i, _ in pairs(array) do
		table.remove(array, i)			
	end
end

local function AededUIResetAllCooldowns(self)
	local selfID = self:GetID()
	
	
	local parentName = self:GetName()
	local array = _G["AededUI_ActiveParty"..selfID.."Timers"]
		
	--for i, _ in pairs(array) do
	for i = 1, 10 do
		local prefix = parentName.."Ability"..i
		local frameName = _G[prefix]
		local frameCooldown = _G[prefix.."Cooldown"]
		frameCooldown:Clear()
		frameName:Hide()
		--print("hiding ", frameName:GetName())
		table.remove(array, i)
	end
end


local function AededUIPartyFrame_SetCooldown(self, spellID, duration, reset)

	local selfID = self:GetID()
	local parentName = self:GetName()
	local array = _G["AededUI_ActiveParty"..selfID.."Timers"]
	local spellName, _, icon = GetSpellInfo(spellID)
	
	for i = 1, 10 do
		
		local prefix = parentName.."Ability"..i
		local frameName = _G[prefix]
		local frameIcon = _G[prefix.."Icon"]
		local frameCooldown = _G[prefix.."Cooldown"]
		
		if not frameName:IsShown() then
			frameName:Show()
			frameIcon:SetTexture(icon)
			frameCooldown:SetCooldown(GetTime(), duration);
			frameCooldown:SetReverse(false)
			table.insert(array, #array+1, {name = parentName, frame = frameName, times = GetTime() + duration, aReset = reset, unitGUID = UnitGUID(self.unit)})
			table.sort(array, function(a,b)
				if a.times < b.times then
					return a.times < b.times
				end		
			end)
			AededUI_Reoriginate(array)
			break
		end
	end
end

local function AededUIPartyFrame_Cooldowns(self, ...)
	if not self:IsVisible() then return end
	local selfID = self:GetID()
	local unit = self.unit
	local duration, reset
	local pet = "partypet"..selfID
	local _, uClass = UnitClass(unit)
	
	local _, eventtype, _, srcGUID, srcName, srcFlags, _,_,_,_,_, spellID, spellName= ...
	
	if ( eventtype == "SPELL_CAST_SUCCESS" and ( UnitGUID(unit) == srcGUID or UnitGUID(pet) == srcGUID )) then
		if ( spellName and ( cooldownPartyFrame[uClass][spellName] or cooldownPartyFrame["GENERAL"][spellName] )) then
			
			if ( spellName == "Cold Snap" ) then
				AededUIResetCooldowns(self)
			elseif( spellName == "Preparation" ) then
				AededUIResetCooldowns(self)
			elseif( spellName == "Readiness" ) then
				AededUIResetCooldowns(self)
			elseif( spellName == "Fel Domination" ) then
				AededUIResetCooldowns(self)
			end
		
			if cooldownPartyFrame[uClass][spellName] then
				duration = cooldownPartyFrame[uClass][spellName].duration
				reset = cooldownPartyFrame[uClass][spellName].reset
			else
				duration = cooldownPartyFrame["GENERAL"][spellName].duration
				reset = cooldownPartyFrame["GENERAL"][spellName].reset
			end
			AededUIPartyFrame_SetCooldown(self, spellID, duration, reset )	
		end
	end
end

local function AededUIPartyFrame_TrinketUpdate(self)
	local spellID, itemID, startTime, duration = C_PvP.GetArenaCrowdControlInfo(self.unit);
	local array = _G["AededUI_ActiveTrinketTimers"]
	
	if (spellID) then
	
		local frameName = self:GetName().."PvPTrinket"
		local trinketFrame = _G[frameName]
		local trinketIcon = _G[frameName.."Icon"]
		local trinketCooldown = _G[frameName.."Cooldown"]
		
		if (spellID ~= trinketFrame.spellID) then
			trinketFrame.spellID = spellID;

			if(itemID ~= 0) then
				local itemTexture = GetItemIcon(itemID);
				trinketIcon:SetTexture(itemTexture);
			else
				local spellTexture, spellTextureNoOverride = GetSpellTexture(spellID);
				trinketIcon:SetTexture(spellTextureNoOverride);
			end
		end
		if (startTime ~= 0 and duration ~= 0) then
			trinketFrame:Show()
			trinketCooldown:SetCooldown(startTime/1000.0, duration/1000.0);
			trinketCooldown:SetReverse(false)
			table.insert(array, #array+1, {frame = trinketFrame, times = GetTime() + duration})
	
		else
			trinketCooldown:Clear();
		end
	end
end

function AededUIParty_Spellbar_OnEvent(self, event, ...)
	local arg1 = ...

	--	Check for target specific events
	if ( (event == "VARIABLES_LOADED") ) then
		if ( not self.showCastbar ) then
			self:Hide();
		elseif ( self.casting or self.channeling ) then
			self:Show();
		end
		return;
	elseif ( event == self.updateEvent ) then
		local nameChannel  = UnitChannelInfo(self.unit);
		local nameSpell  = UnitCastingInfo(self.unit);
		if ( nameChannel ) then
			event = "UNIT_SPELLCAST_CHANNEL_START";
			arg1 = self.unit;
		elseif ( nameSpell ) then
			event = "UNIT_SPELLCAST_START";
			arg1 = self.unit;
		else
			self.casting = nil;
			self.channeling = nil;
			self:SetMinMaxValues(0, 0);
			self:SetValue(0);
			self:Hide();
			return;
		end
	end
	CastingBarFrame_OnEvent(self, event, arg1, select(2, ...));
end

function AededUIPartyMemberFrame_OnEvent(self, event, ...)
	local selfID = self:GetID();
	if ( event == "COMBAT_LOG_EVENT_UNFILTERED" ) then
		if ( selfID < 3 ) then
			AededUIPartyFrame_Cooldowns(self, CombatLogGetCurrentEventInfo())
		end
		return
	end

	AededUIUnitFrame_OnEvent(self, event, ...);

	local arg1, arg2, arg3 = ...;
	local unit = "party"..selfID;
	
	if ( selfID < 3 ) then
		local unitPet = "partypet"..selfID;
	end
	
	if ( event == "PLAYER_ENTERING_WORLD" ) then
		if ( UnitExists("party"..selfID) ) then
			AededUIPartyMemberFrame_UpdateMember(self);
			AededUIPartyMemberFrame_UpdateOnlineStatus(self);
			if ( selfID < 3) then
				AededUIResetAllCooldowns(self)
				AededUIResetAllTrinkets(self)
			end
		end
	elseif ( event == "GROUP_ROSTER_UPDATE" or event == "UPDATE_ACTIVE_BATTLEFIELD" ) then
		AededUIPartyMemberFrame_UpdateMember(self);
		AededUIPartyMemberFrame_UpdateArt(self);
		AededUIPartyMemberFrame_UpdateLeader(self);
		if ( selfID < 3) then
			AededUIResetAllCooldowns(self)
			AededUIResetAllTrinkets(self)
		end
		return;
	elseif ( event == "ARENA_COOLDOWNS_UPDATE" ) then
		if ( arg1 == unit and selfID < 3) then
			AededUIPartyFrame_TrinketUpdate(self);
		end
	elseif ( event == "PARTY_LEADER_CHANGED" ) then
		AededUIPartyMemberFrame_UpdateLeader(self);
	elseif ( event =="UNIT_AURA" ) then
		if ( arg1 == unit ) then
			AededUIRefreshPartyAuras(self, unit, nil, nil);
			AededUIUnitFrame_LoseControl(self);
		else
			if ( arg1 == unitPet ) then
				AededUIPartyMemberFrame_RefreshPetDebuffs(self);
			end
		end
	elseif ( event =="UNIT_PET" ) then
		if ( arg1 == unit ) then
			AededUIPartyMemberFrame_UpdatePet(self);
		end
	elseif ( event == "READY_CHECK" or
		 event == "READY_CHECK_CONFIRM" ) then
		AededUIPartyMemberFrame_UpdateReadyCheck(self);
	elseif ( event == "READY_CHECK_FINISHED" ) then
		if (UnitExists("party"..self:GetID())) then
			local finishTime = DEFAULT_READY_CHECK_STAY_TIME;
			if ( GetDisplayedAllyFrames() ~= "party" ) then
				finishTime = 0;
			end
			ReadyCheck_Finish(_G["AededUIPartyMemberFrame"..self:GetID().."ReadyCheck"], finishTime);
		end
	elseif ( event == "VARIABLES_LOADED" ) then
		AededUIPartyMemberFrame_UpdatePet(self);
	elseif ( event == "UNIT_ENTERED_VEHICLE" ) then
		if ( arg1 == "party"..selfID ) then
			if ( arg2 and UnitIsConnected("party"..selfID) ) then
				AededUIPartyMemberFrame_ToVehicleArt(self, arg3);
			else
				AededUIPartyMemberFrame_ToPlayerArt(self);
			end
		end
	elseif ( event == "UNIT_EXITED_VEHICLE" ) then
		if ( arg1 == "party"..selfID ) then
			AededUIPartyMemberFrame_ToPlayerArt(self);
		end
	elseif ( event == "UNIT_CONNECTION" ) and ( arg1 == "party"..selfID ) then
		AededUIPartyMemberFrame_UpdateArt(self);
		AededUIPartyMemberFrame_UpdateOnlineStatus(self);
	elseif ( event == "UNIT_PHASE" or event == "PARTY_MEMBER_ENABLE" or event == "PARTY_MEMBER_DISABLE" or event == "UNIT_FLAGS") then
		if ( event ~= "UNIT_PHASE" or arg1 == unit ) then
			AededUIPartyMemberFrame_UpdateNotPresentIcon(self);
		end
	elseif ( event == "UNIT_OTHER_PARTY_CHANGED" and arg1 == unit ) then
		AededUIPartyMemberFrame_UpdateNotPresentIcon(self);
	end
end


function AededUIPartyMemberFrame_RefreshPetDebuffs (self, id)
	if ( not id ) then
		id = self:GetID();
	end
	AededUIRefreshDebuffsSmall(_G["AededUIPartyMemberFrame"..id.."PetFrame"], "partypet"..id, nil, nil);
	AededUIUnitFrame_LoseControl(self);
end

function AededUIPartyMemberHealthCheck (self, value)
	local prefix = self:GetParent():GetName();

	if ( UnitIsDead("party"..self:GetParent():GetID()) ) then
		_G[prefix.."Portrait"]:SetVertexColor(0.35, 0.35, 0.35, 1.0);
	elseif ( UnitIsGhost("party"..self:GetParent():GetID()) ) then
		_G[prefix.."Portrait"]:SetVertexColor(0.35, 0.35, 0.35, 1.0);
	else
		_G[prefix.."Portrait"]:SetVertexColor(1.0, 1.0, 1.0, 1.0);
	end
end

function AededUIPartyFrameDropDown_OnLoad (self)
	UIDropDownMenu_SetInitializeFunction(self, AededUIPartyFrameDropDown_Initialize);
	UIDropDownMenu_SetDisplayMode(self, "MENU");
end

function AededUIPartyFrameDropDown_Initialize (self)
	local dropdown = UIDROPDOWNMENU_OPEN_MENU or self;
	AededUIUnitPopup_ShowMenu(dropdown, "PARTY", "party"..dropdown:GetParent():GetID());
end

function AededUIPartyMemberFrame_UpdateStatusBarText ()
	local lockText = nil;
	if ( SHOW_PARTY_TEXT == "1" ) then
		lockText = 1;
	end
	for i=1, AededUI_MAX_PARTY_MEMBERS do
		_G["AededUIPartyMemberFrame"..i.."HealthBar"].forceShow = lockText;
		_G["AededUIPartyMemberFrame"..i.."ManaBar"].forceShow = lockText;
		if ( lockText ) then
			_G["AededUIPartyMemberFrame"..i.."HealthBarText"]:Show();
			_G["AededUIPartyMemberFrame"..i.."ManaBarText"]:Show();
		end
	end
end

function AededUIPartyMemberFrame_UpdateOnlineStatus(self)
	if ( not UnitIsConnected("party"..self:GetID()) ) then
		-- Handle disconnected state
		local selfName = self:GetName();
		local healthBar = _G[selfName.."HealthBar"];
		local unitHPMin, unitHPMax = healthBar:GetMinMaxValues();
		
		_G[selfName.."HealthBarText"]:Hide();
		_G[selfName.."ManaBarText"]:Hide();
		healthBar:SetValue(unitHPMax);
		healthBar:SetStatusBarColor(0.5, 0.5, 0.5);
		SetDesaturation(_G[selfName.."Portrait"], true);
		_G[selfName.."Disconnect"]:Show();
		return;
	else
		local selfName = self:GetName();
		SetDesaturation(_G[selfName.."Portrait"], false);
		_G[selfName.."Disconnect"]:Hide();
	end
end
