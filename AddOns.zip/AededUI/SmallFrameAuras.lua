--[[
local Debuff_Filter_ToT = {
	
	["Mortal Strike"] = 1,
	["Wound Poison"] = 1,
	["Aimed Shot"] = 1,
	["Blood Fury"] = 1,
	
	["Concussive Shot"] = 1,
	["Concussion Blow"] = 1,
	["Intimidation"] = 1,
	["Cheap Shot"] = 1,
	["Kydney Shot"] = 1,
	["Bash"] = 1,
	["Intercept"] = 1,
	["Charge"] = 1,
	["Hammer of Justice"] = 1,
	["War Stomp"] = 1,
	["Shadow Fury"] = 1,
	
	
	
	["Blackout"] = 1,
	["Impact"] = 1,
	["Mace Stun Effect"] = 1,
	["Stun"] = 1,
	["Starfire Stun"] = 1,
	["Pounce"] = 1,
	
	["Counterspell - Silenced"] = 1,
	["Silence"] = 1,
	["Spell Lock"] = 1,
	["Garrote - Silenced"] = 1,
	["Silence Shot"] = 1,
	["Arcane Torrent"] = 1,
	["Unstable Affiction"] = 1,
	
	["Maim"] = 1,
	["Gouge"] = 1,
	["Sap"] = 1,
	["Dragon's Breath"] = 1,
	["Scatter Shot"] = 1,
	["Repetance"] = 1,
	["Cyclone"] = 1,
	
	
	["Hibernate"] = 1,
	["Seduction"] = 1,
	["Wyvern Sting"] = 1,
	["Mind Control"] = 1,
	
	["Blind"] = 1,
	["Polymorph"] = 1,
	["Fear"] = 1,
	["Psychic Scream"] = 1,
	["Howl of Terror"] = 1,
	["Death Coil"] = 1,
	["Death Coil"] = 1,
	
	["Entangling Roots"] = 1,
	["Freeze"] = 1,
	["Frost Nova"] = 1,
	["Frostbite"] = 1,
	["Improved Hamstring"] = 1,
	["Improved Wingclip"] = 1,
	["Entangle"] = 1,
	["Boar Charge"] = 1,
	
	["Cone of Cold"] = 1,
	["Frost Trap"] = 1,
	["Hamstring"] = 1,
	["Piercing Howl"] = 1,
	--misery pve only
}
--]]

SmartDebuffFilter = {

	GENERAL = {
	
		--Spells
		
		["Hemorrhage"] = true,
		["Misery"] = true,
		["Blood Frenzy"] = true,
		["Thunder Clap"] = true,
		["Demoralizing Shout"] = true,
		["Demoralizing Roar"] = true,
		["Challenging Roar"] = true,
		["Challenging Shout"] = true,
		["Growl"] = true,
		["Taunt"] = true,
		["Mocking Blow"] = true,
		--["Shadow Embrace"] = true,
		
		
		--Events & consumables
		["Tricked or Treated"] = true,
        
    },

    DRUID = {
        
    },
	
    HUNTER = {
        
    },
	
    MAGE = {
        
    },
	
    PALADIN = {	
        
    },
	
    PRIEST = {
        
    },
	
	
	ROGUE = {
        
    },
	
	SHAMAN = {
        
    },
	
	WARLOCK = {
        
    },
	
	WARRIOR = {
        
    }
	
}

local SmartBuffFilter = {


	GENERAL_PRIEST = {
	
		--Spells
	
        ["Power Word: Fortitude"] = true,
		["Prayer of Fortitude"] = true,
		["Shadow Protection"] = true,
		["Prayer of Shadow Protection"] = true,
		["Prayer of Spirit"] = true,
		["Divine Spirit"] = true,
    },
	
	GENERAL_DRUID = {
	
		--Spells
	
        ["Mark of the Wild"] = true,
		["Gift of the Wild"] = true,
		["Thorns"] = true,
		
    },
	
	GENERAL_MAGE = {
	
		--Spells
	
        ["Arcane Intellect"] = true,
		["Arcane Brilliance"] = true,
		
    },
	
	GENERAL_SHAMAN = {
	
		["Grounding Totem Effect"] = true,
		["Stoneskin"] = true,
		["Grace of Air"] = true,
		["Healing Stream"] = true,
		["Strenght of Earth"] = true,
		["Earth Shield"] = true,
		
    },
	
	GENERAL_ROGUE = {
	
		--Spells
	
       
		
    },
	
	GENERAL_HUNTER = {
	
		--Spells
	
        
    },
	
	GENERAL_WARLOCK = {
	
		--Spells
	
        
    },
	
	GENERAL_WARRIOR = {
	
		--Spells
	
        ["Battle Shout"] = true,
		["Commanding Shout"] = true,
		
    },
	
	GENERAL_PALADIN = {
	
		--Spells
	
        ["Blessing of Light"] = true,
		["Blessing of Might"] = true,
		["Blessing of Kings"] = true,
		["Blessing of Wisdom"] = true,
		["Blessing of Salvation"] = true,
		["Greater Blessing of Light"] = true,
		["Greater Blessing of Might"] = true,
		["Greater Blessing of Kings"] = true,
		["Greater Blessing of Wisdom"] = true,
		["Greater Blessing of Salvation"] = true,
		["Concentration Aura"] = true,
    },

	GENERAL = {	
	
		--Trinkets
		["Electrical Charge"] = true,
		["Holy Energy"] = true,
		["Fel Infusion"] = true,
		["Call of the Berserker"] = true,
		["Mojo Madness"] = true,
		["Tremendous Fortitude"] = true,
		
		--Racials
		
		["Shadowmeld"] = true,
		["Stoneform"] = true,
		["Gift of the Naaru"] = true,
		["Preception"] = true,
		["Blood Fury"] = true,
		["Berserking"] = true,
		["Will of the Forsaken"] = true,

		--Party buffs
		["Soulstone Resurrection"] = true,
		--["mounts"] = true,
		
		
		["Grounding Totem Effect"] = true,
		["Intervene"] = true,
		
		["Fear Ward"] = true,
		["Power Word: Shield"] = true,
		["Renew"] = true,
		["Abolish Disease"] = true,
		["Power Infusion"] = true,
		["Pain Suppression"] = true,
		["Prayer of Mending"] = true,
		
		["Innervate"] = true,
		
		["Heroism"] = true,
		["Bloodlust"] = true,
		

		["Blessing of Freedom"] = true,
		["Blessing of Protection"] = true,
		["Divine Intervention"] = true,
		["Blessing of Sacrifice"] = true,
		--["auras? other blessings?"] = true,

		["Aspect of the Pack"] = true,
		["Aspect of the Wild"] = true,


		["Regrowth"] = true,
		["Lifebloom"] = true,
		["Rejuvenation"] = true,
		["Abolish Poison"] = true,
		["Tranquility"] = true,
		
    },

    
    DRUID = {	
	
		--Spells
		
        ["Bear Form"] = true,
		["Moonkin Form"] = true,
		["Tree of Life"] = true,
		["Dire Bear Form"] = true,
		["Cat Form"] = true,
		["Aquatic Form"] = true,
		["Travel Form"] = true,
		["Flight Form"] = true,
		["Swift Flight Form"] = true,

		["Barkskin"] = true,
		["Dash"] = true,
		["Frenzied Regeneration"] = true,
		["Hurricane"] = true,
		["Prowl"] = true,

		--Talents

		["Nature's Grasp"] = true,
		["Nature's Swiftness"] = true,
		["Moonkin Form"] = true,
		["Nature's Grace"] = true,
		["Wrath of Elune"] = true,

    },
    HUNTER = {
	
		--Spells
	
        ["Tame Beast"] = true,
		["Eyes of the Beast"] = true,
		["Aspect of the Cheetah"] = true,
		["Aspect of the Monkey"] = true,
		["Aspect of the Beast"] = true,
		["Aspect of the Hawk"] = true,
		["Rapid Fire"] = true,
		["Feign Death"] = true,
		["Volley"] = true,

		--Talents

		["Deterrence"] = true
		
    },
	MAGE = {	
	
		--Spells
	
 
		["Blink"] = true,
		["Evocation"] = true,
		["Frost Armor"] = true,
		["Mage Armor"] = true,
		["Fire Ward"] = true,
		["Frost Ward"] = true,
		["Ice Armor"] = true,
		["Mana Shield"] = true,

		--Talents

		["Ice Barrier"] = true,
		["Ice Block"] = true,
		["Combustion"] = true,
		["Arcane Power"] = true,
		["Presence of Mind"] = true,
		["Clearcasting"] = true
		
    },
	PALADIN = {
	
		--Spells
     
		["Divine Shield"] = true,
		["Divine Protection"] = true,
		["Summon Warhorse"] = true,
		["Summon Charger"] = true,

		--Talents

		["Divine Favor"] = true,
		["Reckoning"] = true,
		["Avenging Wrath"] = true,
		["Divine Illumination"] = true,
    },
	PRIEST = {
	
		--Spells
	
		["Mind Vision"] = true,
		["Mind Control"] = true,
		["Elune's Grace"] = true,
		["Feedback"] = true,
		["Inner Fire"] = true,

		--Talents

		["Shadowform"] = true,
		["Spirit of Redemption"] = true,
		["Inner Focus"] = true,
		["Focused Casting"] = true,
		["Lightwell Renew"] = true,
		["Deep Meditation"] = true,
		

		
    },
	ROGUE = {
	
		--Spells
	
		["Stealth"] = true,
		["Cloak of Shadows"] = true,
		["Vanish"] = true,
		["Evasion"] = true,
		["Sprint"] = true,
		["Feint"] = true,

		--Talents

		["Adrenaline Rush"] = true,
		["Cold Blood"] = true,
		["Ghostly Strike"] = true,
		["Blade Flurry"] = true,
		["Remorseless"] = true
		
    },
    SHAMAN = {
	
		--Spells
	
		["Ghost Wolf"] = true,
		["Far Sight"] = true,

		--Talents
			
		["Nature's Swiftness"] = true,
		["Elemental Mastery"] = true,
		["Eye of the Storm"] = true,


    },
	WARLOCK = {
			
		--Spells
		
		["Hellfire"] = true,
		["Summon Felsteel"] = true,
		["Summon Dreadsteed"] = true,
		["Eye of Kilrogg"] = true,
		["Drain Mana"] = true,
		["Demon Armor"] = true,
		["Demon Skin"] = true,
		["Fel Armor"] = true,
		["Health Funnel"] = true,
		["Shadow Ward"] = true,
		
		--Talents
		
		["Fel Domination"] = true,
		["Amplify Curse"] = true,
		["Nightfall"] = true,
		["Soul Link"] = true,
		["Demonic Sacrifice"] = true

    },
	WARRIOR = {
	
		--Spells
	
		["Shield Wall"] = true,
		["Berserker Rage"] = true,
		["Retaliation"] = true,
		["Recklessness"] = true,
		["Mocking Blow"] = true,



		--Talents
		

		--["Blood Craze"] = true,
		["Sweeping Strikes"] = true,
		["Last Stand"] = true,

    },
}

local Buff_Filter_Lowrank = {
	
	["Renew"] = 1,
	["Power Word: Fortitude"] = 1,
	
	
	["Blessing of Might"] = 1,
	["Blessing of Wisdom"] = 1,
	["Blessing of Light"] = 1,
	
	
	["Mend Pet"] = 1,
	
	
	["Mark of the Wild"] = 1,
	["Water Shield"] = 1,
	--["Thorns"] = 1,

}

local Debuff_Filter_Lowrank = {
	
	["Moonfire"] = 1,
	["Shadow Word: Pain"] = 1,
	["Insect Swarm"] = 1,
	
	["Hunter's Mark"] = 1,
	["Serpent Sting"] = 1,
	["Blessing of Light"] = 1,
	
	
	["Corruption"] = 1,
	["Siphon Life"] = 1,
	["Curse of Agony"] = 1,
	["Immolate"] = 1,

}

local DebuffFilterToT = {
	
	-- Druid
	
	["Mangle (Cat)"] = 1,
	["Mangle (Bear)"] = 1,
	
	-- Hunter
	
	["Expose Weakness"] = 1,
	["Deadly Poison"] = 1,
	
	-- Mage
	
	["Fireball"] = 1,
	["Pyroblast"] = 1,
	["Winter's Chill"] = 1,
	
	-- Paladin
	
	["Vindication"] = 1,
	
	-- Priest
	
	
	["Misery"] = 1,
	["Shadow Weawing"] = 1,

	-- Rogue
	
	["Hemorrhage"] = 1,
	
	-- Warlock
	
	["Shadow Embrace"] = 1,
	
	-- Warrior
	
	["Blood Frenzy"] = 1,

}




local function hideDebuffs(frameName, suffix)

	for i = 1, 4 do
		local debuffFrame = _G[frameName..suffix..i];
		debuffFrame:Hide()
	end
	
end

local function GetDebuffName(frameName, suffix)

	for i = 1, 4 do
		local debuffName = frameName..suffix..i;
		local debuffFrame = _G[debuffName]
		
		if not debuffFrame:IsShown() then
				
			return debuffName
			
		end
	end
	
	return nil
	
end

local function UpdatePartyBuffPositions(self, selfName, numBuffs, size, iconGap)

	for i=1, numBuffs do
		-- update size and offset info based on large aura status
		
		local buff = _G[selfName..i]
		
		-- anchor the current aura
		if ( i == 1 ) then 
		
			buff:SetPoint("CENTER", self, "CENTER", -10, -12);
		
		elseif (i <= 5) then
		
			buff:SetPoint("CENTER", selfName.."1", "CENTER", ((i-1)*(size+iconGap)) , 0);
		
		else
		
			buff:SetPoint("CENTER", selfName.."1", "CENTER", -(7*(size+iconGap))+((i-1)*(size+iconGap)) , -(size + iconGap));
		
		end
		
		buff:SetWidth(size);
		buff:SetHeight(size);
	end

end

local function UpdatePartyDebuffPositions(self, selfName, numDebuffs, size, iconGap)
	
	for i=1, numDebuffs do
		-- update size and offset info based on large aura status
		
		local debuff = _G[selfName..i]
		
		-- anchor the current aura
		if ( i == 1 ) then 
		
			debuff:SetPoint("CENTER", self, "TOPRIGHT", -1, 0);
		
		elseif (i <= 6) then
		
			debuff:SetPoint("CENTER", selfName.."1", "CENTER", ((i-1)*(size+iconGap)) , 0);
		
		else
		
			debuff:SetPoint("CENTER", selfName.."1", "CENTER", -(6*(size+iconGap))+((i-1)*(size+iconGap)) , -(size + iconGap));
		
		end
		
		debuff:SetWidth(size);
		debuff:SetHeight(size);
	end
	
end


local function hideAuras(frameName)

	for i = 1, MAX_TARGET_BUFFS do
		local auraFrame = _G[frameName.."Buff"..i];
		if auraFrame then
			auraFrame:Hide()
		end
	end
	
	for i = 1, MAX_TARGET_DEBUFFS do
		local auraFrame = _G[frameName.."Debuff"..i];
		if auraFrame then
			auraFrame:Hide()
		end
	end
	
end

function AededUIRefreshPartyAuras(self, unit, numDebuffs, suffix, checkCVar)
	
	local selfName = self:GetName();
	
	hideAuras(selfName, "Debuff")

	local unitStatus, statusColor;
	local frame, frameName
	local lowrank, lowrankName;
	local frameIcon, frameCount, frameCooldown;
	local playerIsTarget = UnitIsUnit(PlayerFrame.unit, self.unit);
	local _, uClass = UnitClass(self.unit)
	local _, pClass = UnitClass("player")
	local numBuffs = 0;
	
	hideAuras(selfName)

	for i = 1, 24 do 
        local buffName, icon, count, _, duration, expirationTime, caster, _, _, spellId, _, _, _, nameplateShowAll = UnitBuff(self.unit, i, nil)
		if (buffName) then
			if ( ( icon and ( not self.maxBuffs or i <= self.maxBuffs ) ) and ((uClass and SmartBuffFilter[uClass][buffName]) or SmartBuffFilter["GENERAL"][buffName] or SmartBuffFilter["GENERAL_"..pClass][buffName])) then
				local _, rank = GetSpellInfo(spellId)
				numBuffs = numBuffs + 1;
				frameName = selfName.."Buff"..numBuffs;
				frame = _G[frameName];
				
				if ( not frame ) then
					if ( not icon ) then
						break;
					else
						frame = CreateFrame("Button", frameName, self, "AededUIPartyBuffFrameTemplate");
						frame.unit = self.unit;
					end
				end
				
				
					frame:SetID(i);

                -- set the icon
					frameIcon = _G[frameName.."Icon"];
					frameIcon:SetTexture(icon);

					-- set the count
					
					frame:CreateFontString(frameName.."Count", "OVERLAY")
					frameCount = _G[frameName.."Count"];
					frameCount:ClearAllPoints()
					frameCount:SetPoint("BOTTOM", frame, "BOTTOMRIGHT", -2.5, 0.5);
					frameCount:SetFont("Fonts\\FRIZQT__.TTF", 8, "OUTLINE")
					
					
					if ( count > 1) then
						frameCount:SetText(count);
						frameCount:Show();
					else
						frameCount:Hide();
					end
					
					-- Handle cooldowns
					
					frameCooldown = _G[frameName.."Cooldown"];
		
		
					if duration and (duration < 600) then
						CooldownFrame_Set(frameCooldown, expirationTime - duration, duration + 0.05, duration > 0, true);
						frameCooldown:SetDrawEdge(false)
					else
						frameCooldown:Clear()
					end
					

					frame:ClearAllPoints();
					frame:Show();
					
					if Buff_Filter_Lowrank[name] and rank then
					
						lowrankName = "lowrank_string_"..i
						lowrank = _G[lowrankName]
						
			
						if ((string.find(rank, "1") or string.find(rank, "2")))then
		
							if not lowrank then

								local lowrank_string = frame:CreateFontString(lowrankName, "OVERLAY", "TextStatusBarText")
								lowrank:SetFont("Fonts\\FRIZQT__.TTF", 6.5, "OUTLINE")
								lowrank_string:ClearAllPoints()
								lowrank_string:SetPoint("TOPLEFT", frameName, 0.75, 0.75);
								lowrank_string:SetTextColor(1, 0, 0);

							end

							lowrank:SetText("x")
							lowrank:Show()
				
						else
			
							if lowrank then
		
								lowrank:Hide()
		 
							end
			
						end
					
					end
			end
        else
            break;
        end
	end

	for i = numBuffs + 1, 24 do
		local frame = _G[selfName.."Buff"..i];
		if ( frame ) then
			frame:Hide();
		else
			break;
		end
	end

	local color;
	local frameBorder;
	local numDebuffs = 0;

	local frameNum = 1;
	local index = 1;

	local maxDebuffs = 12;
	while ( frameNum <= maxDebuffs and index <= maxDebuffs ) do
	    local debuffName, icon, count, debuffType, duration, expirationTime, caster, _, _, spellId, _, _, _, nameplateShowAll = UnitDebuff(self.unit, index, nil);
		if ( debuffName ) then
	
			if ( icon and ( not SmartDebuffFilter["GENERAL"][debuffName] or (uClass and SmartDebuffFilter[uClass][debuffName])) ) then
				local _, rank = GetSpellInfo(spellId)
				numDebuffs = numDebuffs + 1;
				frameName = selfName.."Debuff"..numDebuffs;
				frame = _G[frameName];
					if ( not frame ) then
						frame = CreateFrame("Button", frameName, self, "AededUIPartyDebuffFrameTemplate");
						frame.unit = self.unit;
					end
					frame:SetID(index);
					
					-- set the icon
					frameIcon = _G[frameName.."Icon"];
					frameIcon:SetTexture(icon);

					-- set the count
					frame:CreateFontString(frameName.."Count", "OVERLAY")
					frameCount = _G[frameName.."Count"];
					frameCount:ClearAllPoints()
					frameCount:SetPoint("BOTTOM", frame, "BOTTOMRIGHT", -2, 0.5);
					frameCount:SetFont("Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
					if ( count > 1) then
						frameCount:SetText(count);
						frameCount:Show();
					else
						frameCount:Hide();
					end

					-- Handle cooldowns
					frameCooldown = _G[frameName.."Cooldown"];
					
					if duration and (duration < 600) then
						
						CooldownFrame_Set(frameCooldown, expirationTime - duration, duration + 0.05, duration > 0, true);
					else
						frameCooldown:Clear()
					end
					-- set debuff type color
					if ( debuffType ) then
						color = DebuffTypeColor[debuffType];
					else
						color = DebuffTypeColor["none"];
					end
					frameBorder = _G[frameName.."Border"];
					frameBorder:SetVertexColor(color.r, color.g, color.b);

					-- set the debuff to be big if the buff is cast by the player or his pet
					
					

					frame:ClearAllPoints();
					frame:Show();

					frameNum = frameNum + 1;
					
					if Debuff_Filter_Lowrank[name] and rank then
					
						lowrankName = "lowrank_string_"..i
						lowrank = _G[lowrankName]
					
						if ((string.find(rank, "1") or string.find(rank, "2")))then
		
							if not lowrank then

								local lowrank_string = frame:CreateFontString(lowrankName, "OVERLAY")
								lowrank:SetFont("Fonts\\FRIZQT__.TTF", 6.5, "OUTLINE")
								lowrank_string:ClearAllPoints()
								lowrank_string:SetPoint("TOPLEFT", frameName, 0.75, 0.75);
								lowrank_string:SetTextColor(1, 0, 0);

							end

							lowrank:SetText("x")
							lowrank:Show()
				
						else
			
							if lowrank then
		
								lowrank:Hide()
		 
							end
						end
					end	
			end
		else
			break;
		end
		index = index + 1;
	end

	for i = frameNum, MAX_TARGET_DEBUFFS do
		local frame = _G[selfName.."Debuff"..i];
		if ( frame ) then
			frame:Hide();
		else
			break;
		end
	end

	self.auraRows = 0;
	
	-- update buff positions (iconsize, iconGap)
	UpdatePartyBuffPositions(self, selfName.."Buff", numBuffs, 13.5, 1);
	
	-- update debuff positions (iconsize, iconGap)
	UpdatePartyDebuffPositions(self, selfName.."Debuff", numDebuffs, 16, 2.5);
	-- update the spell bar position

	if ( unitStatus and statusColor ) then
		unitStatus:SetVertexColor(statusColor.r, statusColor.g, statusColor.b);
	end


end

function AededUIRefreshDebuffsSmall(frame, unit, numDebuffs, suffix, checkCVar)
	
	local frameName = frame:GetName();

	frame.hasDispellable = nil;
	
	suffix = suffix or "Debuff";
	
	numDebuffs = numDebuffs or MAX_TARGET_DEBUFFS;
	
	local unitStatus, statusColor;
	local debuffFrame
	local debuffTotal = 0;
	local name, icon, count, debuffType, duration, expirationTime

	hideDebuffs(frameName, suffix)
	
	for i=1, numDebuffs do
	
		name, icon, count, debuffType, duration, expirationTime = UnitDebuff(unit, i);
		
		if ( icon and not DebuffFilterToT[name] ) then
			
			local debuffName = GetDebuffName(frameName, suffix)
			
			if not debuffName then
				return
			end
			debuffFrame = _G[debuffName]
			debuffFrame:SetID(i)
			
		
			--debuffFrame:ClearAllPoints();
			-- if we have an icon to show then proceed with setting up the aura

			-- set the icon
			local debuffIcon = _G[debuffName.."Icon"];
			debuffIcon:SetTexture(icon);

			-- setup the border
			local debuffBorder = _G[debuffName.."Border"];
			local debuffColor = DebuffTypeColor[debuffType] or DebuffTypeColor["none"];
			debuffBorder:SetVertexColor(debuffColor.r, debuffColor.g, debuffColor.b);
			-- record interesting data for the aura button
			
			statusColor = debuffColor;
			frame.hasDispellable = 1;
			debuffTotal = debuffTotal + 1;
			local frameCount = _G[debuffName.."Count"];

			
			if ( count > 1 ) then
				frameCount:SetText(count);
				frameCount:Show();
			else
				frameCount:Hide();
			end
			--]]
			debuffFrame:Show();
			
		end
	end

	frame.debuffTotal = debuffTotal;
	-- Reset unitStatus overlay graphic timer
	if ( frame.numDebuffs and debuffTotal >= frame.numDebuffs ) then
		frame.debuffCountdown = 30;
	end
	if ( unitStatus and statusColor ) then
		unitStatus:SetVertexColor(statusColor.r, statusColor.g, statusColor.b);
	end


end


function AededUIRefreshBuffs(frame, unit, numBuffs, suffix, checkCVar)
	local frameName = frame:GetName();
	frame.hasDispellable = nil;
	numBuffs = numBuffs or MAX_PARTY_BUFFS;
	suffix = suffix or "Buff";
	local unitStatus, statusColor;
	local debuffTotal = 0;
	local filter = ( checkCVar and SHOW_CASTABLE_BUFFS == "1" and UnitCanAssist("player", unit) ) and "HELPFUL|RAID" or "HELPFUL";
	local numFrames = 0;
	AuraUtil.ForEachAura(unit, filter, numBuffs, function(...)
		local name, icon, count, debuffType, duration, expirationTime = ...;
		-- if we have an icon to show then proceed with setting up the aura
		if ( icon ) then
			numFrames = numFrames + 1;
			local buffName = frameName..suffix..numFrames;
			-- set the icon
			local buffIcon = _G[buffName.."Icon"];
			buffIcon:SetTexture(icon);
			-- setup the cooldown
			local coolDown = _G[buffName.."Cooldown"];
			if ( coolDown ) then
				CooldownFrame_Set(coolDown, expirationTime - duration, duration, true);
			end
			-- show the aura
			_G[buffName]:Show();
		end
		return numFrames >= numBuffs;
	end);
	for i=numFrames + 1,numBuffs do
		local buffName = frameName..suffix..i;
		local frame = _G[buffName];
		if frame then
			frame:Hide();
		else
			break;
		end
	end
end


--[[
hooksecurefunc("RefreshDebuffs", function(frame, unit, numDebuffs, suffix, checkCVar)
	
	local frameName = frame:GetName();
	--print(frameName)
	if ( frameName == "TargetFrameToT" ) then

		AededUIRefreshDebuffsSmall(frame, unit, numDebuffs, suffix, nil)
		
	end
	
end)--]]