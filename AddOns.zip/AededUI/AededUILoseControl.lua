

local function UpdatePortrait(self)

	local frameName = self:GetName()
	local textureFrame = _G[frameName.."Texture"]
	local cooldownFrame = _G[frameName.."Cooldown"]
	
    if ( self.currentAuraSpellID and self.currentAuraDuration > 0 and self.currentLoseControlStartTime ~= self.currentAuraStartTime ) then
		cooldownFrame:SetCooldown(self.currentAuraStartTime, self.currentAuraDuration + 0.05)
        self.currentLoseControlStartTime = self.currentAuraStartTime
    elseif ( self.currentAuraDuration == 0 ) then
		cooldownFrame:Clear()
        self.currentLoseControlStartTime = 0
    end
	
    local texture = self.currentAuraSpellID and self.currentAuraTexture
    if ( self.currentLoseControlTexture == texture) then 
		return
	end

    self.currentLoseControlTexture = texture
	textureFrame:SetTexture(texture)
end


function AededUIUnitFrame_LoseControl(self)

	local frameName = self:GetName().."LoseControl"
	local frame = _G[frameName]
    local unit = self.unit
	
    local currentSpellID, currentDuration, currentExpirationTime, currentTexture = nil, 0, 0, nil

    if ( self.currentInterruptSpellID ) then
        currentSpellID = frame.currentInterruptSpellID
        currentDuration = frame.currentInterruptDuration
        currentExpirationTime = frame.currentInterruptExpirationTime
        currentTexture = frame.currentInterruptTexture
    end


        local filter = ("HARMFUL")

        for n = 1, 30 do
            local _, texture, _, _, duration, expirationTime, _, _, _, spellID = UnitAura(unit, n, filter)

            if ( not spellID ) then break end

            if ( AededUI_AuraList[spellID] ) then
                if ( not currentSpellID or AededUI_AuraList[spellID] < AededUI_AuraList[currentSpellID] ) then
                    currentSpellID = spellID
                    currentDuration = duration
                    currentExpirationTime = expirationTime
                    currentTexture = texture
                end
            end
        end


    if ( currentSpellID ) then

        frame.currentAuraSpellID = currentSpellID
        frame.currentAuraStartTime = currentExpirationTime - currentDuration
        frame.currentAuraDuration = currentDuration
        frame.currentAuraTexture = currentTexture
    else
	
        frame.currentAuraSpellID = nil
        frame.currentAuraStartTime = 0
        frame.currentAuraDuration = 0
        frame.currentAuraTexture = nil
    end

    UpdatePortrait(frame)
end

