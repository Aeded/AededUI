
function AededUIPlayerFrame_OnLoad(self)
	AededUIPlayerFrameHealthBar.LeftText = AededUIPlayerFrameHealthBarTextLeft;
	AededUIPlayerFrameHealthBar.RightText = AededUIPlayerFrameHealthBarTextRight;
	AededUIPlayerFrameManaBar.LeftText = AededUIPlayerFrameManaBarTextLeft;
	AededUIPlayerFrameManaBar.RightText = AededUIPlayerFrameManaBarTextRight;

	AededUIUnitFrame_Initialize(self, "player", AededUIPlayerName, AededUIPlayerPortrait,
						 AededUIPlayerFrameHealthBar, AededUIPlayerFrameHealthBarText,
						 AededUIPlayerFrameManaBar, AededUIPlayerFrameManaBarText,
						 nil, nil, nil,
						 AededUIPlayerFrameMyHealPredictionBar, AededUIPlayerFrameOtherHealPredictionBar,
						 AededUIPlayerFrameTotalAbsorbBar, AededUIPlayerFrameTotalAbsorbBarOverlay, AededUIPlayerFrameOverAbsorbGlow,
						 AededUIPlayerFrameOverHealAbsorbGlow, AededUIPlayerFrameHealAbsorbBar, AededUIPlayerFrameHealAbsorbBarLeftShadow,
						 AededUIPlayerFrameHealAbsorbBarRightShadow, AededUIPlayerFrameManaCostPredictionBar);

	self.statusCounter = 0;
	self.statusSign = -1;
	AededUIPlayerFrame_Update();
	self:RegisterEvent("UNIT_LEVEL");
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
	self:RegisterEvent("PLAYER_ENTER_COMBAT");
	self:RegisterEvent("PLAYER_LEAVE_COMBAT");
	self:RegisterEvent("PLAYER_REGEN_DISABLED");
	self:RegisterEvent("PLAYER_REGEN_ENABLED");
	self:RegisterEvent("PLAYER_UPDATE_RESTING");
	self:RegisterEvent("PARTY_LEADER_CHANGED");
	self:RegisterEvent("GROUP_ROSTER_UPDATE");
	self:RegisterEvent("READY_CHECK");
	self:RegisterEvent("READY_CHECK_CONFIRM");
	self:RegisterEvent("READY_CHECK_FINISHED");
	self:RegisterUnitEvent("UNIT_MAXPOWER", "player", "vehicle");
	self:RegisterUnitEvent("UNIT_AURA", "player");

	self:SetClampRectInsets(20, 0, 0, 0);

	local showmenu = function()
		ToggleDropDownMenu(1, nil, AededUIPlayerFrameDropDown, "AededUIPlayerFrame", 106, 27);
	end
	--UIParent_UpdateTopFramePositions();
	SecureUnitButton_OnLoad(self, "player", showmenu);
end

--This is overwritten in LocalizationPost for different languages.
function AededUIPlayerFrame_UpdateLevelTextAnchor(level)
	if ( level >= 100 ) then
		AededUIPlayerLevelText:SetPoint("CENTER", AededUIPlayerFrameTexture, "CENTER", -64, -16);
	else
		AededUIPlayerLevelText:SetPoint("CENTER", AededUIPlayerFrameTexture, "CENTER", -63, -16);
	end
end

function AededUIPlayerFrame_Update ()
	if ( UnitExists("player") ) then
		local level = UnitLevel(AededUIPlayerFrame.unit);
		AededUIPlayerLevelText:SetVertexColor(1.0, 0.82, 0.0, 1.0);
		AededUIPlayerFrame_UpdateLevelTextAnchor(level);
		AededUIPlayerLevelText:SetText(level);
		AededUIPlayerFrame_UpdatePartyLeader();
		AededUIPlayerFrame_UpdateStatus();
		AededUIPlayerFrame_UpdateLayout();
	end
end

function AededUIPlayerFrame_UpdatePartyLeader()
	if ( UnitIsGroupLeader("player") ) then
		AededUIPlayerLeaderIcon:Show()
	else
		AededUIPlayerLeaderIcon:Hide();
	end

	local lootMethod, lootMaster = GetLootMethod();
	if ( lootMaster == 0 and IsInGroup() ) then
		AededUIPlayerMasterIcon:Show();
	else
		AededUIPlayerMasterIcon:Hide();
	end
end

function AededUIPlayerFrame_OnEvent(self, event, ...)
	AededUIUnitFrame_OnEvent(self, event, ...);

	local arg1, arg2, arg3, arg4, arg5 = ...;
	if ( event == "UNIT_LEVEL" ) then
		if ( arg1 == "player" ) then
			AededUIPlayerFrame_Update();
		end
	elseif ( event == "PLAYER_ENTERING_WORLD" ) then
		AededUIPlayerFrame_ResetPosition(self);
		AededUIPlayerFrame_ToAededUIPlayerArt(self);
		AededUIUnitFrame_SetUnit(self, "player", AededUIPlayerFrameHealthBar, AededUIPlayerFrameManaBar);
		self.inCombat = nil;
		self.onHateList = nil;
		AededUIPlayerFrame_Update();
		AededUIPlayerFrame_UpdateStatus();
	elseif ( event == "UNIT_AURA" ) then
		if ( arg1 == self.unit ) then
			AededUIUnitFrame_LoseControl(self);
		end
	elseif ( event == "PLAYER_ENTER_COMBAT" ) then
		self.inCombat = 1;
		AededUIPlayerFrame_UpdateStatus();
	elseif ( event == "PLAYER_LEAVE_COMBAT" ) then
		self.inCombat = nil;
		AededUIPlayerFrame_UpdateStatus();
	elseif ( event == "PLAYER_REGEN_DISABLED" ) then
		self.onHateList = 1;
		AededUIPlayerFrame_UpdateStatus();
	elseif ( event == "PLAYER_REGEN_ENABLED" ) then
		self.onHateList = nil;
		AededUIPlayerFrame_UpdateStatus();
	elseif ( event == "PLAYER_UPDATE_RESTING" ) then
		AededUIPlayerFrame_UpdateStatus();
	elseif ( event == "PARTY_LEADER_CHANGED" or event == "GROUP_ROSTER_UPDATE" ) then
		AededUIPlayerFrame_UpdatePartyLeader();
		AededUIPlayerFrame_UpdateReadyCheck();
	elseif ( event == "READY_CHECK" or event == "READY_CHECK_CONFIRM" ) then
		AededUIPlayerFrame_UpdateReadyCheck();
	elseif ( event == "READY_CHECK_FINISHED" ) then
		ReadyCheck_Finish(AededUIPlayerFrameReadyCheck, DEFAULT_READY_CHECK_STAY_TIME);
	elseif ( event == "UNIT_ENTERING_VEHICLE" ) then
		if ( arg1 == "player" ) then
			if ( arg2 ) then
				AededUIPlayerFrame_AnimateOut(self);
			else
				if ( AededUIPlayerFrame.state == "vehicle" ) then
					AededUIPlayerFrame_AnimateOut(self);
				end
			end
		end
	elseif ( event == "UNIT_ENTERED_VEHICLE" ) then
		if ( arg1 == "player" ) then
			self.inSeat = true;
			if (UnitInVehicleHidesPetFrame("player")) then
				self.vehicleHidesPet = true;
			end
			AededUIPlayerFrame_UpdateArt(self);
		end
	elseif ( event == "UNIT_EXITING_VEHICLE" ) then
		if ( arg1 == "player" ) then
			if ( self.state == "vehicle" ) then
				AededUIPlayerFrame_AnimateOut(self);
			else
				self.updatePetFrame = true;
			end
			self.vehicleHidesPet = false;
		end
	elseif ( event == "UNIT_EXITED_VEHICLE" ) then
		if ( arg1 == "player" ) then
			self.inSeat = true;
			AededUIPlayerFrame_UpdateArt(self);
		end
	end
end

local function AededUIPlayerFrame_AnimPos(self, fraction)
	return "TOPLEFT", UIParent, "TOPLEFT", -19, fraction*140-4;
end

function AededUIPlayerFrame_ResetPosition(self)
	CancelAnimations(AededUIPlayerFrame);
	self.isAnimatedOut = false;
	UIParent_UpdateTopFramePositions();
	self.inSequence = false;
	AededUIPetFrame_Update(PetFrame);
end

local AededUIPlayerFrameAnimTable = {
	totalTime = 0.3,
	updateFunc = "SetPoint",
	getPosFunc = AededUIPlayerFrame_AnimPos,
	}
function AededUIPlayerFrame_AnimateOut(self)
	self.inSeat = false;
	self.animFinished = false;
	self.inSequence = true;
	self.isAnimatedOut = true;
	if ( self:IsUserPlaced() ) then
		AededUIPlayerFrame_AnimFinished(AededUIPlayerFrame);
	else
		SetUpAnimation(AededUIPlayerFrame, AededUIPlayerFrameAnimTable, AededUIPlayerFrame_AnimFinished, false)
	end
end

function AededUIPlayerFrame_AnimFinished(self)
	self.animFinished = true;
	AededUIPlayerFrame_UpdateArt(self);
end

function AededUIPlayerFrame_IsAnimatedOut(self)
	return self.isAnimatedOut;
end

function AededUIPlayerFrame_UpdateArt(self)
	if ( self.animFinished and self.inSeat and self.inSequence) then
		if ( self:IsUserPlaced() ) then
			AededUIPlayerFrame_SequenceFinished(AededUIPlayerFrame);
		else
			SetUpAnimation(AededUIPlayerFrame, AededUIPlayerFrameAnimTable, AededUIPlayerFrame_SequenceFinished, true)
		end
		AededUIPlayerFrame_ToAededUIPlayerArt(self);
	elseif ( self.updatePetFrame ) then
		-- leaving a vehicle that didn't change player art
		self.updatePetFrame = false;
		PetFrame_Update(PetFrame);
	end
end

function AededUIPlayerFrame_SequenceFinished(self)
	self.inSequence = false;
	PetFrame_Update(PetFrame);
end

function AededUIPlayerFrame_ToVehicleArt(self, vehicleType)
	--Swap frame

	AededUIPlayerFrame.state = "vehicle";

	AededUIUnitFrame_SetUnit(self, "vehicle", AededUIPlayerFrameHealthBar, AededUIPlayerFrameManaBar);
	AededUIUnitFrame_SetUnit(AededUIPetFrame, "player", AededUIPetFrameHealthBar, AededUIPetFrameManaBar);
	AededUIPetFrame_Update(PetFrame);
	AededUIPlayerFrame_Update();
	BuffFrame_Update();
	ComboFrame_Update(ComboFrame);

	AededUIPlayerFrameTexture:Hide();
	if ( vehicleType == "Natural" ) then
		AededUIPlayerFrameVehicleTexture:SetTexture("Interface\\Vehicles\\UI-Vehicle-Frame-Organic");
		AededUIPlayerFrameHealthBar:SetWidth(103);
		AededUIPlayerFrameHealthBar:SetPoint("TOPLEFT",116,-41);
		AededUIPlayerFrameManaBar:SetWidth(103);
		AededUIPlayerFrameManaBar:SetPoint("TOPLEFT",116,-52);
	else
		AededUIPlayerFrameVehicleTexture:SetTexture("Interface\\Vehicles\\UI-Vehicle-Frame");
		AededUIPlayerFrameHealthBar:SetWidth(100);
		AededUIPlayerFrameHealthBar:SetPoint("TOPLEFT",119,-41);
		AededUIPlayerFrameManaBar:SetWidth(100);
		AededUIPlayerFrameManaBar:SetPoint("TOPLEFT",119,-52);
	end
	AededUIPlayerFrame_ShowVehicleTexture();

	AededUIPlayerName:SetPoint("CENTER",50,23);
	AededUIPlayerLeaderIcon:SetPoint("TOPLEFT",44,-10);

	AededUIPlayerFrameBackground:SetWidth(114);
	AededUIPlayerLevelText:Hide();
end

function AededUIPlayerFrame_ToAededUIPlayerArt(self)
	--Unswap frame

	AededUIPlayerFrame.state = "player";

	AededUIUnitFrame_SetUnit(self, "player", AededUIPlayerFrameHealthBar, AededUIPlayerFrameManaBar);
	AededUIUnitFrame_SetUnit(AededUIPetFrame, "pet", AededUIPetFrameHealthBar, AededUIPetFrameManaBar);
	AededUIPetFrame_Update(PetFrame);
	AededUIPlayerFrame_Update();
	BuffFrame_Update();
	ComboFrame_Update(ComboFrame);

	AededUIPlayerFrameTexture:Show();
	AededUIPlayerFrame_HideVehicleTexture();
	AededUIPlayerName:SetPoint("CENTER",50,19);
	AededUIPlayerLeaderIcon:SetPoint("TOPLEFT",44,-10);
	AededUIPlayerFrameHealthBar:SetWidth(119);
	AededUIPlayerFrameHealthBar:SetPoint("TOPLEFT",106,-41);
	AededUIPlayerFrameManaBar:SetWidth(119);
	AededUIPlayerFrameManaBar:SetPoint("TOPLEFT",106,-52);
	AededUIPlayerFrameBackground:SetWidth(119);
	AededUIPlayerLevelText:Show();
end

function AededUIPlayerFrame_UpdateVoiceStatus (status)
	AededUIPlayerSpeakerFrame:Hide();
end

function AededUIPlayerFrame_UpdateReadyCheck ()
	local readyCheckStatus = GetReadyCheckStatus("player");
	if ( readyCheckStatus ) then
		if ( readyCheckStatus == "ready" ) then
			ReadyCheck_Confirm(AededUIPlayerFrameReadyCheck, 1);
		elseif ( readyCheckStatus == "notready" ) then
			ReadyCheck_Confirm(AededUIPlayerFrameReadyCheck, 0);
		else -- "waiting"
			ReadyCheck_Start(AededUIPlayerFrameReadyCheck);
		end
	else
		AededUIPlayerFrameReadyCheck:Hide();
	end
end


function AededUIPlayerFrame_OnReceiveDrag ()
	if ( CursorHasItem() ) then
		AutoEquipCursorItem();
	end
end

function AededUIPlayerFrame_UpdateStatus()
	if ( IsResting() ) then
		AededUIPlayerRestIcon:Show();
		AededUIPlayerAttackIcon:Hide();
	elseif ( AededUIPlayerFrame.inCombat and UnitAffectingCombat("player")) then
		AededUIPlayerAttackIcon:Show();
		AededUIPlayerRestIcon:Hide();
	elseif ( AededUIPlayerFrame.onHateList ) then
		AededUIPlayerAttackIcon:Show();
		AededUIPlayerRestIcon:Hide();
	else
		AededUIPlayerRestIcon:Hide();
		AededUIPlayerAttackIcon:Hide();
	end
end


function AededUIPlayerFrameDropDown_OnLoad (self)
	UIDropDownMenu_SetInitializeFunction(self, AededUIPlayerFrameDropDown_Initialize);
	UIDropDownMenu_SetDisplayMode(self, "MENU");
end

function AededUIPlayerFrameDropDown_Initialize ()
	if ( AededUIPlayerFrame.unit == "vehicle" ) then
		AededUIUnitPopup_ShowMenu(AededUIPlayerFrameDropDown, "VEHICLE", "vehicle");
	else
		AededUIUnitPopup_ShowMenu(AededUIPlayerFrameDropDown, "SELF", "player");
	end
end

function AededUIPlayerFrame_SetupDeathKnightLayout ()
	AededUIPlayerFrame:SetHitRectInsets(0,0,0,33);
end

function AededUIPlayerFrameMultiGroupFrame_OnLoad(self)
	self:RegisterEvent("GROUP_ROSTER_UPDATE");
	self:RegisterEvent("UPDATE_CHAT_COLOR");
	self:RegisterForClicks("LeftButtonUp", "RightButtonUp");
end

function AededUIPlayerFrameMultiGroupFrame_OnEvent(self, event, ...)
	if ( event == "GROUP_ROSTER_UPDATE" ) then
		if ( IsInGroup(LE_PARTY_CATEGORY_HOME) and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) ) then
			self:Show();
		else
			self:Hide();
		end
	elseif ( event == "UPDATE_CHAT_COLOR" ) then
		local public = ChatTypeInfo["INSTANCE_CHAT"];
		local private = ChatTypeInfo["PARTY"];
		self.HomePartyIcon:SetVertexColor(private.r, private.g, private.b);
		self.InstancePartyIcon:SetVertexColor(public.r, public.g, public.b);
	end
end

function AededUIPlayerFrameMultiGroupframe_OnEnter(self)
	GameTooltip_SetDefaultAnchor(GameTooltip, self);
	self.homePlayers = GetHomePartyInfo(self.homePlayers);

	if ( IsInRaid(LE_PARTY_CATEGORY_HOME) ) then
		GameTooltip:SetText(PLAYER_IN_MULTI_GROUP_RAID_MESSAGE, nil, nil, nil, nil, true);
		GameTooltip:AddLine(format(MEMBER_COUNT_IN_RAID_LIST, #self.homePlayers + 1), 1, 1, 1, true);
	else
		GameTooltip:AddLine(PLAYER_IN_MULTI_GROUP_PARTY_MESSAGE, 1, 1, 1, true);
		local playerList = self.homePlayers[1] or "";
		for i=2, #self.homePlayers do
			playerList = playerList..PLAYER_LIST_DELIMITER..self.homePlayers[i];
		end
		GameTooltip:AddLine(format(MEMBERS_IN_PARTY_LIST, playerList));
	end
	GameTooltip:Show();
end

AededUICustomClassLayouts = {
	["DEATHKNIGHT"] = AededUIPlayerFrame_SetupDeathKnightLayout,
}

local layoutUpdated = false;

function AededUIPlayerFrame_UpdateLayout ()
	if ( layoutUpdated ) then
		return;
	end
	layoutUpdated = true;

	local _, class = UnitClass("player");

	if ( AededUICustomClassLayouts[class] ) then
		AededUICustomClassLayouts[class]();
	end
end

local RUNICPOWERBARHEIGHT = 63;
local RUNICPOWERBARWIDTH = 64;

local RUNICGLOW_FADEALPHA = .050
local RUNICGLOW_MINALPHA = .40
local RUNICGLOW_MAXALPHA = .80
local RUNICGLOW_THROBINTERVAL = .8;

local RUNICGLOW_FINISHTHROBANDHIDE = false;
local RUNICGLOW_THROBSTART = 0;

function AededUIPlayerFrame_SetRunicPower (runicPower)
	AededUIPlayerFrameRunicPowerBar:SetHeight(RUNICPOWERBARHEIGHT * (runicPower / 100));
	AededUIPlayerFrameRunicPowerBar:SetTexCoord(0, 1, (1 - (runicPower / 100)), 1);

	if ( runicPower >= 90 ) then
		-- Oh,  God help us for these function and variable names.
		RUNICGLOW_FINISHTHROBANDHIDE = false;
		if ( not AededUIPlayerFrameRunicPowerGlow:IsShown() ) then
			AededUIPlayerFrameRunicPowerGlow:Show();
		end
		AededUIPlayerFrameRunicPowerGlow:GetParent():SetScript("OnUpdate", AededUIDeathKnniggetThrobFunction);
	elseif ( AededUIPlayerFrameRunicPowerGlow:GetParent():GetScript("OnUpdate") ) then
		RUNICGLOW_FINISHTHROBANDHIDE = true;
	else
		AededUIPlayerFrameRunicPowerGlow:Hide();
	end
end

local firstFadeIn = true;
function AededUIDeathKnniggetThrobFunction (self, elapsed)
	if ( RUNICGLOW_THROBSTART == 0 ) then
		RUNICGLOW_THROBSTART = GetTime();
	elseif ( not RUNICGLOW_FINISHTHROBANDHIDE ) then
		local interval = RUNICGLOW_THROBINTERVAL - math.abs( .9 - (UnitPower("player") / 100));
		local animTime = GetTime() - RUNICGLOW_THROBSTART;
		if ( animTime >= interval ) then
			-- Fading out
			AededUIPlayerFrameRunicPowerGlow:SetAlpha(math.max(RUNICGLOW_MINALPHA, math.min(RUNICGLOW_MAXALPHA, RUNICGLOW_MAXALPHA * interval/animTime)));
			if ( animTime >= interval * 2 ) then
				self.timeSinceThrob = 0;
				RUNICGLOW_THROBSTART = GetTime();
			end
			firstFadeIn = false;
		else
			-- Fading in
			if ( firstFadeIn ) then
				AededUIPlayerFrameRunicPowerGlow:SetAlpha(math.max(RUNICGLOW_FADEALPHA, math.min(RUNICGLOW_MAXALPHA, RUNICGLOW_MAXALPHA * animTime/interval)));
			else
				AededUIPlayerFrameRunicPowerGlow:SetAlpha(math.max(RUNICGLOW_MINALPHA, math.min(RUNICGLOW_MAXALPHA, RUNICGLOW_MAXALPHA * animTime/interval)));
			end
		end
	elseif ( RUNICGLOW_FINISHTHROBANDHIDE ) then
		local currentAlpha = AededUIPlayerFrameRunicPowerGlow:GetAlpha();
		local animTime = GetTime() - RUNICGLOW_THROBSTART;
		local interval = RUNICGLOW_THROBINTERVAL;
		firstFadeIn = true;

		if ( animTime >= interval ) then
			-- Already fading out, just keep fading out.
			local alpha = math.min(AededUIPlayerFrameRunicPowerGlow:GetAlpha(), RUNICGLOW_MAXALPHA * (interval/(animTime*(animTime/2))));

			AededUIPlayerFrameRunicPowerGlow:SetAlpha(alpha);
			if ( alpha <= RUNICGLOW_FADEALPHA ) then
				self.timeSinceThrob = 0;
				RUNICGLOW_THROBSTART = 0;
				AededUIPlayerFrameRunicPowerGlow:Hide();
				self:SetScript("OnUpdate", nil);
				RUNICGLOW_FINISHTHROBANDHIDE = false;
				return;
			end
		else
			-- Was fading in, start fading out
			animTime = interval;
		end
	end
end



function AededUIPlayerFrame_ShowVehicleTexture()
	AededUIPlayerFrameVehicleTexture:Show();

	local _, class = UnitClass("player");
	if ( AededUIPlayerFrame.classPowerBar ) then
		AededUIPlayerFrame.classPowerBar:Hide();
	end
end


function AededUIPlayerFrame_HideVehicleTexture()
	AededUIPlayerFrameVehicleTexture:Hide();

	local _, class = UnitClass("player");
	if ( AededUIPlayerFrame.classPowerBar ) then
		AededUIPlayerFrame.classPowerBar:Setup();
	end
end
