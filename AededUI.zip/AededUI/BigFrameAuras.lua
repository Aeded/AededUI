
local Buff_Filter = {

	["Ferocious Inspiration"] = 1,
	["Flurry"] = 1,
	["Spirit Bond"] = 1,
	["Blood Craze"] = 1,
	["Totemic Mastery"] = 1,
	["Unleashed Rage"] = 1,
	["Demonic Knowledge"] = 1,
	["Heroic Presence"] = 1,
	["Health Funnel"] = 1,
	["Inspiring Presence"] = 1,
	["Heroic Presence"] = 1,

}

local Debuff_Filter = {
	
	["Blood Frenzy"] = 1,
	["Hemorrhage"] = 1,
	["Misery"] = 1,
}


local Buff_Filter_Lowrank = {
	
	["Renew"] = 1,
	["Power Word: Fortitude"] = 1,
	
	
	["Blessing of Might"] = 1,
	["Blessing of Wisdom"] = 1,
	["Blessing of Light"] = 1,
	
	
	["Mend Pet"] = 1,
	
	
	["Mark of the Wild"] = 1,
	["Water Shield"] = 1,
	--["Thorns"] = 1,

}

local Debuff_Filter_Lowrank = {
	
	["Moonfire"] = 1,
	["Shadow Word: Pain"] = 1,
	["Insect Swarm"] = 1,
	
	["Hunter's Mark"] = 1,
	["Serpent Sting"] = 1,
	["Blessing of Light"] = 1,
	
	
	["Corruption"] = 1,
	["Siphon Life"] = 1,
	["Curse of Agony"] = 1,
	["Immolate"] = 1,

}

local AURA_START_X = 5-1;
local AURA_START_Y = 32+1;
local AURA_OFFSET = 1;
local DEBUFF_AURA_SIZE = 20;
local BUFF_AURA_SIZE = 18.5;
local AURA_ROW_WIDTH = 184;
local AURA_ROW_WIDTH_BUFF = 160;
local TOT_AURA_ROW_WIDTH = 101;
local NUM_TOT_AURA_ROWS = 2;	-- TODO: replace with TOT_AURA_ROW_HEIGHT functionality if this becomes a problem

-- focus frame scales
local LARGE_FOCUS_SCALE = 1;
local SMALL_FOCUS_SCALE = 0.75;
local SMALL_FOCUS_UPSCALE = 1.333;



local function UpdateBuffAnchor(self, buffName, index, numDebuffs, anchorIndex, size, OffsetX, OffsetY, mirrorVertically)
	

	local buff = _G[buffName..index];
	
	if ( index == 1 ) then
	
		if ( UnitIsFriend("player", self.unit) or numDebuffs == 0 ) then
		
			buff:SetPoint("TOPLEFT", self, "BOTTOMLEFT", AURA_START_X, AURA_START_Y);
		
			
		else
			-- -AURA_OFFSET + 1 because above it are larger debuffs
			buff:SetPoint("TOPLEFT", self.debuffs, "BOTTOMLEFT", 0, -OffsetY);
			
			
		end
		
		self.buffs:SetPoint("TOPLEFT", buff, "TOPLEFT", 0, 0);
		self.buffs:SetPoint("BOTTOMLEFT", buff, "BOTTOMLEFT", 0, -OffsetY); --??
		self.spellbarAnchor = buff;
		
	elseif ( anchorIndex ~= (index-1) ) then
	
		-- anchor index is not the previous index...must be a new row
		
		buff:SetPoint("TOPLEFT", _G[buffName..anchorIndex], "BOTTOMLEFT", 0, -OffsetY);
		self.buffs:SetPoint("BOTTOMLEFT", buff, "BOTTOMLEFT", 0, -OffsetY);
		self.spellbarAnchor = buff;
		
	else
		-- anchor index is the previous index
		buff:SetPoint("TOPLEFT", _G[buffName..anchorIndex], "TOPRIGHT", OffsetX, 0);
	end


	buff:SetWidth(size);
	buff:SetHeight(size);
end

local function UpdateDebuffAnchor(self, debuffName, index, numBuffs, anchorIndex, size, OffsetX, OffsetY, mirrorVertically)
	local debuff = _G[debuffName..index];
	local isFriend = UnitIsFriend("player", self.unit);


	if ( index == 1 ) then
		if ( isFriend and numBuffs > 0 ) then
			-- unit is friendly and there are buffs...debuffs start on bottom
			debuff:SetPoint("TOPLEFT", self.buffs, "BOTTOMLEFT", 0, -OffsetY);
		else
			-- unit is not friendly or there are no buffs...debuffs start on top
			debuff:SetPoint("TOPLEFT", self, "BOTTOMLEFT", AURA_START_X, AURA_START_Y);
		end
		
		self.debuffs:SetPoint("TOPLEFT", debuff, "TOPLEFT", 0, 0);
		--AURA_OFFSET
		self.debuffs:SetPoint("BOTTOMLEFT", debuff, "BOTTOMLEFT", 0, -OffsetY);
		
		if ( ( isFriend ) or ( not isFriend and numBuffs == 0) ) then
			self.spellbarAnchor = debuff;
		end
	elseif ( anchorIndex ~= (index-1) ) then
		-- anchor index is not the previous index...must be a new row
		debuff:SetPoint("TOPLEFT", _G[debuffName..anchorIndex], "BOTTOMLEFT", 0, -OffsetY);
		self.debuffs:SetPoint("BOTTOMLEFT", debuff, "BOTTOMLEFT", 0, -OffsetY);
		if ( ( isFriend ) or ( not isFriend and numBuffs == 0) ) then
			self.spellbarAnchor = debuff;
		end
	else
		-- anchor index is the previous index
		debuff:SetPoint("TOPLEFT", _G[debuffName..(index-1)], "TOPRIGHT", OffsetX, 0);
	end

	-- Resize
	debuff:SetWidth(size);
	debuff:SetHeight(size);
	
	local debuffFrame =_G[debuffName..index.."Border"];
	
	debuffFrame:SetWidth(size+2);
	debuffFrame:SetHeight(size+2);
end


local function UpdateBuffPositions(self, auraName, numAuras, numOppositeAuras, updateFunc, maxRowWidth, offsetX, mirrorAurasVertically)
	-- a lot of this complexity is in place to allow the auras to wrap around the target of target frame if it's shown

	-- Position auras
	local size = BUFF_AURA_SIZE
	local offsetX = 1;
	local offsetY = 1;
	-- current width of a row, increases as auras are added and resets when a new aura's width exceeds the max row width
	local rowWidth = 0;
	local firstBuffOnRow = 1;
	for i=1, numAuras do
		-- update size and offset info based on large aura status
		

		-- anchor the current aura
		if ( i == 1 ) then
			rowWidth = 2*(size + offsetX);
			self.auraRows = self.auraRows + 1;
		else
			rowWidth = rowWidth + size + offsetX;
		end
		if ( rowWidth > maxRowWidth ) then
			-- this aura would cause the current row to exceed the max row width, so make this aura
			-- the start of a new row instead
			updateFunc(self, auraName, i, numOppositeAuras, firstBuffOnRow, size, offsetX, offsetY, false);

			rowWidth = size;
			self.auraRows = self.auraRows + 1;
			firstBuffOnRow = i;
			

			if ( self.auraRows > NUM_TOT_AURA_ROWS ) then
				-- if we exceed the number of tot rows, then reset the max row width
				-- note: don't have to check if we have tot because AURA_ROW_WIDTH is the default anyway
				maxRowWidth = AURA_ROW_WIDTH_BUFF;
			end
		else
			updateFunc(self, auraName, i, numOppositeAuras, i - 1, size, offsetX, offsetY, false);
		end
	end
end

local function UpdateDebuffPositions(self, auraName, numAuras, numOppositeAuras, updateFunc, maxRowWidth, offsetX, mirrorAurasVertically)
	-- a lot of this complexity is in place to allow the auras to wrap around the target of target frame if it's shown

	-- Position auras
	local size = DEBUFF_AURA_SIZE
	local offsetX = 2.5;
	local offsetY = 2.5;
	-- current width of a row, increases as auras are added and resets when a new aura's width exceeds the max row width
	local rowWidth = 0;
	local firstBuffOnRow = 1;
	for i=1, numAuras do
		-- update size and offset info based on large aura status
		

		-- anchor the current aura
		if ( i == 1 ) then
			rowWidth = 3*(size + offsetX);
			self.auraRows = self.auraRows + 1;
		else
			rowWidth = rowWidth + size + offsetX;
		end
		if ( rowWidth > maxRowWidth ) then
			-- this aura would cause the current row to exceed the max row width, so make this aura
			-- the start of a new row instead
			updateFunc(self, auraName, i, numOppositeAuras, firstBuffOnRow, size, offsetX, offsetY, false);

			rowWidth = size;
			self.auraRows = self.auraRows + 1;
			firstBuffOnRow = i;
		

			if ( self.auraRows > NUM_TOT_AURA_ROWS ) then
				-- if we exceed the number of tot rows, then reset the max row width
				-- note: don't have to check if we have tot because AURA_ROW_WIDTH is the default anyway
				maxRowWidth = AURA_ROW_WIDTH;
			end
		else
			updateFunc(self, auraName, i, numOppositeAuras, i - 1, size, offsetX, offsetY, false);
		end
	end
end

local function hideAuras(frameName)

	for i = 1, MAX_TARGET_BUFFS do
		local auraFrame = _G[frameName.."Buff"..i];
		if auraFrame then
			auraFrame:Hide()
		end
	end
	
	for i = 1, MAX_TARGET_DEBUFFS do
		local auraFrame = _G[frameName.."Debuff"..i];
		if auraFrame then
			auraFrame:Hide()
		end
	end
	
end



hooksecurefunc("TargetFrame_UpdateAuras", function(self)


	local frame, frameName;
	local lowrank, lowrankName;
	local frameIcon, frameCount, frameCooldown;
	local numBuffs = 0;
	local playerIsTarget = UnitIsUnit(PlayerFrame.unit, self.unit);
	local selfName = self:GetName();
	
	hideAuras(selfName)

	for i = 1, MAX_TARGET_BUFFS do 
        local buffName, icon, count, _, duration, expirationTime, caster, _, _, spellId, _, _, _, nameplateShowAll = UnitBuff(self.unit, i, nil);
		if (buffName) then
			if ( ( icon and ( not self.maxBuffs or i <= self.maxBuffs )) and not Buff_Filter[buffName] ) then
				local _, rank = GetSpellInfo(spellId)
				numBuffs = numBuffs + 1;
				frameName = selfName.."Buff"..numBuffs;
				frame = _G[frameName];
				--[[
				if ( not frame ) then
					if ( not icon ) then
						break;
					else
						frame = CreateFrame("Button", frameName, self, "TargetBuffFrameTemplate");
						frame.unit = self.unit;
						
					end
				end
				--]]
					frame:SetID(i);

                -- set the icon
					frameIcon = _G[frameName.."Icon"];
					frameIcon:SetTexture(icon);

					-- set the count
					frameCount = _G[frameName.."Count"];
					frameCount:SetFont("Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
					frameCount:ClearAllPoints()
					frameCount:SetPoint("CENTER", frame, "BOTTOMRIGHT", -1.5, 3);
					
					if ( count > 1 ) then
						frameCount:SetText(count);
						frameCount:Show();
					else
						frameCount:Hide();
					end
					
					local frameStealable = _G[frameName.."Stealable"];
					if frameStealable:IsShown() then
					
						frameStealable:Hide();
						
					end
					-- Handle cooldowns
					frameCooldown = _G[frameName.."Cooldown"];
					if duration and (duration < 599) then
						CooldownFrame_Set(frameCooldown, expirationTime - duration, duration, duration > 0, false);
					else
						CooldownFrame_Clear(frameCooldown);
					end
					

					frame:ClearAllPoints();
					frame:Show();
				
					
					if Buff_Filter_Lowrank[name] and rank then
					
						lowrankName = "lowrank_string_"..i
						lowrank = _G[lowrankName]
						
			
						if ((string.find(rank, "1") or string.find(rank, "2")))then
		
							if not lowrank then

								local lowrank_string = frame:CreateFontString(lowrankName, "OVERLAY")
								lowrank:SetFont("Fonts\\FRIZQT__.TTF", 6.5, "OUTLINE")
								lowrank_string:ClearAllPoints()
								lowrank_string:SetPoint("TOPLEFT", frameName, 0.75, 0.75);
								lowrank_string:SetTextColor(1, 0, 0);

							end

							lowrank:SetText("x")
							lowrank:Show()
				
						else
			
							if lowrank then
		
								lowrank:Hide()
		 
							end
			
						end
					
					end	
			end
        else
            break;
        end
	end

	for i = numBuffs + 1, MAX_TARGET_BUFFS do
		local frame = _G[selfName.."Buff"..i];
		if ( frame ) then
			frame:Hide();
		else
			break;
		end
	end

	local color;
	local frameBorder;
	local numDebuffs = 0;

	local frameNum = 1;
	local index = 1;

	local maxDebuffs = self.maxDebuffs or MAX_TARGET_DEBUFFS;
	while ( frameNum <= maxDebuffs and index <= maxDebuffs ) do
	    local debuffName, icon, count, debuffType, duration, expirationTime, caster, _, _, _, _, _, _, nameplateShowAll = UnitDebuff(self.unit, index, "INCLUDE_NAME_PLATE_ONLY");
		if ( debuffName ) then
			if ( icon and not Debuff_Filter[debuffName] ) then
				local _, rank = GetSpellInfo(spellId)
				numDebuffs = numDebuffs + 1;
				frameName = selfName.."Debuff"..numDebuffs;
				frame = _G[frameName];
					
					--[[
					if ( not frame ) then
						frame = CreateFrame("Button", frameName, self, "TargetDebuffFrameTemplate");
						frame.unit = self.unit;
					end
					..]]
					frame:SetID(index);

					-- set the icon
					frameIcon = _G[frameName.."Icon"];
					frameIcon:SetTexture(icon);

					-- set the count
					frameCount = _G[frameName.."Count"];
					frameCount:SetFont("Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
					frameCount:ClearAllPoints()
					frameCount:SetPoint("CENTER", frame, "BOTTOMRIGHT", -1.5, 3);
					if ( count > 1 ) then
						frameCount:SetText(count);
						frameCount:Show();
					else
						frameCount:Hide();
					end

					-- Handle cooldowns
					frameCooldown = _G[frameName.."Cooldown"];
					if duration and (duration < 600) then
						CooldownFrame_Set(frameCooldown, expirationTime - duration, duration, duration > 0, true);
					else
						frameCooldown:Clear()
					end
					-- set debuff type color
					if ( debuffType ) then
						color = DebuffTypeColor[debuffType];
					else
						color = DebuffTypeColor["none"];
					end
					frameBorder = _G[frameName.."Border"];
					frameBorder:SetVertexColor(color.r, color.g, color.b);

				
					
					

					frame:ClearAllPoints();
					frame:Show();

					frameNum = frameNum + 1;
					
					
					if Debuff_Filter_Lowrank[name] and rank then
					
						lowrankName = "lowrank_string_"..i
						lowrank = _G[lowrankName]
			
						if ((string.find(rank, "1") or string.find(rank, "2")))then
		
							if not lowrank then

								local lowrank_string = frame:CreateFontString(lowrankName, "OVERLAY")
								lowrank:SetFont("Fonts\\FRIZQT__.TTF", 6.5, "OUTLINE")
								lowrank_string:ClearAllPoints()
								lowrank_string:SetPoint("TOPLEFT", frameName, 0.75, 0.75);
								lowrank_string:SetTextColor(1, 0, 0);

							end

							lowrank:SetText("x")
							lowrank:Show()
				
						else
			
							if lowrank then
		
								lowrank:Hide()
		 
							end
			
						end
					
					end	
			end
		else
			break;
		end
		index = index + 1;
	end

	for i = frameNum, MAX_TARGET_DEBUFFS do
		local frame = _G[selfName.."Debuff"..i];
		if ( frame ) then
			frame:Hide();
		else
			break;
		end
	end

	self.auraRows = 0;

	local mirrorAurasVertically = false;
	if ( self.buffsOnTop ) then
		mirrorAurasVertically = true;
	end
	local haveTargetofTarget;
	if ( self.totFrame ) then
		haveTargetofTarget = self.totFrame:IsShown();
	end
	self.spellbarAnchor = nil;
	
	-- update buff positions
	
	
	UpdateBuffPositions(self, selfName.."Buff", numBuffs, numDebuffs, UpdateBuffAnchor, AURA_ROW_WIDTH_BUFF, 3, mirrorAurasVertically);
	-- update debuff positions
	
	
	UpdateDebuffPositions(self, selfName.."Debuff", numDebuffs, numBuffs, UpdateDebuffAnchor, AURA_ROW_WIDTH, 3, mirrorAurasVertically);
	-- update the spell bar position
	if ( self.spellbar ) then
		Target_Spellbar_AdjustPosition(self.spellbar);
	end
end)