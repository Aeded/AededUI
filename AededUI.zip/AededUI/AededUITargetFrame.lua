
local Buff_Filter = {

	["Ferocious Inspiration"] = 1,
	["Flurry"] = 1,
	["Spirit Bond"] = 1,
	["Blood Craze"] = 1,
	["Totemic Mastery"] = 1,
	["Unleashed Rage"] = 1,
	["Demonic Knowledge"] = 1,
	["Heroic Presence"] = 1,
	["Health Funnel"] = 1,
	["Inspiring Presence"] = 1,
	["Heroic Presence"] = 1,
	["Sign of Battle"] = 1,

}

local Debuff_Filter = {
	
	["Blood Frenzy"] = 1,
	["Hemorrhage"] = 1,
	["Misery"] = 1,
}


local Buff_Filter_Lowrank = {
	
	["Renew"] = 1,
	["Power Word: Fortitude"] = 1,
	
	
	["Blessing of Might"] = 1,
	["Blessing of Wisdom"] = 1,
	["Blessing of Light"] = 1,
	
	
	["Mend Pet"] = 1,
	
	
	["Mark of the Wild"] = 1,
	["Water Shield"] = 1,
	--["Thorns"] = 1,

}

local Debuff_Filter_Lowrank = {
	
	["Moonfire"] = 1,
	["Shadow Word: Pain"] = 1,
	["Insect Swarm"] = 1,
	
	["Hunter's Mark"] = 1,
	["Serpent Sting"] = 1,
	["Blessing of Light"] = 1,
	
	
	["Corruption"] = 1,
	["Siphon Life"] = 1,
	["Curse of Agony"] = 1,
	["Immolate"] = 1,

}

local AURA_START_X = 5-1;
local AURA_START_Y = 32+1;
local AURA_OFFSET = 1;
local DEBUFF_AURA_SIZE = 20;
local BUFF_AURA_SIZE = 18.5;
local AURA_ROW_WIDTH = 184;
local AURA_ROW_WIDTH_BUFF = 160;
local TOT_AURA_ROW_WIDTH = 101;
local NUM_TOT_AURA_ROWS = 2;	-- TODO: replace with TOT_AURA_ROW_HEIGHT functionality if this becomes a problem

-- focus frame scales
local LARGE_FOCUS_SCALE = 1;
local SMALL_FOCUS_SCALE = 0.75;
local SMALL_FOCUS_UPSCALE = 1.333;


local PLAYER_UNITS = {
	player = true,
	vehicle = true,
	pet = true,
};

function AededUITargetFrame_OnLoad(self, unit, menuFunc)
	self.HealthBar.LeftText = self.textureFrame.HealthBarTextLeft;
	self.HealthBar.RightText = self.textureFrame.HealthBarTextRight;
	self.PowerBar.LeftText = self.textureFrame.ManaBarTextLeft;
	self.PowerBar.RightText = self.textureFrame.ManaBarTextRight;

	self.statusCounter = 0;
	self.statusSign = -1;
	self.unitHPPercent = 1;

	local thisName = self:GetName();
	self.borderTexture = _G[thisName.."TextureFrameTexture"];
	self.highLevelTexture = _G[thisName.."TextureFrameHighLevelTexture"];
	self.leaderIcon = _G[thisName.."TextureFrameLeaderIcon"];
	self.raidTargetIcon = _G[thisName.."TextureFrameRaidTargetIcon"];
	self.questIcon = _G[thisName.."TextureFrameQuestIcon"];
	self.levelText = _G[thisName.."TextureFrameLevelText"];
	self.deadText = _G[thisName.."TextureFrameDeadText"];
	self.unconsciousText = _G[thisName.."TextureFrameUnconsciousText"];
	self.TOT_AURA_ROW_WIDTH = TOT_AURA_ROW_WIDTH;
	-- set simple frame
	if ( not self.showLevel ) then
		self.highLevelTexture:Hide();
		self.levelText:Hide();
	end

	-- set portrait frame
	local portraitFrame;
	if ( self.showPortrait ) then
		portraitFrame = _G[thisName.."Portrait"];
	end

	AededUIUnitFrame_Initialize(self, unit, self.textureFrame.Name, portraitFrame,
						self.HealthBar, self.textureFrame.HealthBarText,
						self.PowerBar, self.textureFrame.ManaBarText,
	                     nil, "player", nil,
						 nil, nil,
						 nil, nil, nil,
						 nil, nil, 
						 nil, nil);
						
	AededUITargetFrame_Update(self);
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
	self:RegisterEvent("UNIT_HEALTH");
	if ( self.showLevel ) then
		self:RegisterEvent("UNIT_LEVEL");
	end
	self:RegisterEvent("UNIT_FACTION");
	if ( self.showClassification ) then
		self:RegisterEvent("UNIT_CLASSIFICATION_CHANGED");
	end
	if ( self.showLeader ) then
		self:RegisterEvent("PLAYER_FLAGS_CHANGED");
	end
	self:RegisterEvent("GROUP_ROSTER_UPDATE");
	self:RegisterEvent("RAID_TARGET_UPDATE");
	self:RegisterUnitEvent("UNIT_AURA", unit);

	local frameLevel = _G[thisName.."TextureFrame"]:GetFrameLevel();

	local showmenu;
	if ( menuFunc ) then
		local dropdown = _G[thisName.."DropDown"];
		UIDropDownMenu_SetInitializeFunction(dropdown, menuFunc);
		UIDropDownMenu_SetDisplayMode(dropdown, "MENU");

		showmenu = function()
			ToggleDropDownMenu(1, nil, dropdown, thisName, 120, 10);
		end
	end
	SecureUnitButton_OnLoad(self, self.unit, showmenu);
end

function AededUITargetFrame_Update (self)
	-- This check is here so the frame will hide when the target goes away
	-- even if some of the functions below are hooked by addons.
	if ( UnitExists(self.unit) or not ShowBossFrameWhenUninteractable(self.unit) ) then
		-- Moved here to avoid taint from functions below
		if ( self.totFrame ) then
			AededUITargetofTarget_Update(self.totFrame);
		end
	
		AededUIUnitFrame_Update(self);
		if ( self.showLevel ) then
			AededUITargetFrame_CheckLevel(self);
		end
		AededUITargetFrame_CheckFaction(self);
		if ( self.showClassification ) then
			AededUITargetFrame_CheckClassification(self);
		end
		AededUITargetFrame_CheckDead(self);
		if ( self.showLeader ) then
			if ( UnitLeadsAnyGroup(self.unit) ) then
				self.leaderIcon:SetTexture("Interface\\GroupFrame\\UI-Group-LeaderIcon");
				self.leaderIcon:SetTexCoord(0, 1, 0, 1);
				self.leaderIcon:Show();
			else
				self.leaderIcon:Hide();
			end
		end
		AededUITargetFrame_UpdateAuras(self);
		AededUIUnitFrame_LoseControl(self);
		if ( self.portrait ) then
			self.portrait:SetAlpha(1.0);
		end
	end
end

function AededUITargetFrame_OnEvent (self, event, ...)
	AededUIUnitFrame_OnEvent(self, event, ...);

	local arg1 = ...;
	if ( event == "PLAYER_ENTERING_WORLD" ) then
		AededUITargetFrame_Update(self);
	elseif ( event == "PLAYER_TARGET_CHANGED" ) then
		-- Moved here to avoid taint from functions below
		AededUITargetFrame_Update(self);
		AededUITargetFrame_UpdateRaidTargetIcon(self);
		CloseDropDownMenus();
		if ( UnitExists(self.unit) and not IsReplacingUnit()) then
			if ( UnitIsEnemy(self.unit, "player") ) then
				PlaySound(SOUNDKIT.IG_CREATURE_AGGRO_SELECT);
			elseif ( UnitIsFriend("player", self.unit) ) then
				PlaySound(SOUNDKIT.IG_CHARACTER_NPC_SELECT);
			else
				PlaySound(SOUNDKIT.IG_CREATURE_NEUTRAL_SELECT);
			end
		end
	elseif ( event == "INSTANCE_ENCOUNTER_ENGAGE_UNIT" ) then
		for i = 1, MAX_BOSS_FRAMES do
			AededUITargetFrame_Update(_G["Boss"..i.."AededUITargetFrame"]);
			AededUITargetFrame_UpdateRaidTargetIcon(_G["Boss"..i.."AededUITargetFrame"]);
		end
		CloseDropDownMenus();
		UIParent_ManageFramePositions();
	elseif ( event == "UNIT_TARGETABLE_CHANGED" and arg1 == self.unit) then
		AededUITargetFrame_Update(self);
		AededUITargetFrame_UpdateRaidTargetIcon(self);
		CloseDropDownMenus();
		UIParent_ManageFramePositions();
	elseif ( event == "UNIT_HEALTH" ) then
		if ( arg1 == self.unit ) then
			AededUITargetFrame_CheckDead(self);
		end
	elseif ( event == "UNIT_LEVEL" ) then
		if ( arg1 == self.unit ) then
			AededUITargetFrame_CheckLevel(self);
		end
	elseif ( event == "UNIT_FACTION" ) then
		if ( arg1 == self.unit or arg1 == "player" ) then
			AededUITargetFrame_CheckFaction(self);
			AededUITargetFrame_UpdateAuras(self);
			AededUIUnitFrame_LoseControl(self);
			if ( self.showLevel ) then
				AededUITargetFrame_CheckLevel(self);
			end
		end
	elseif ( event == "UNIT_CLASSIFICATION_CHANGED" ) then
		if ( arg1 == self.unit ) then
			AededUITargetFrame_CheckClassification(self);
		end
	elseif ( event == "UNIT_AURA" ) then
		if ( arg1 == self.unit ) then
			AededUITargetFrame_UpdateAuras(self);
			AededUIUnitFrame_LoseControl(self);
		end
	elseif ( event == "PLAYER_FLAGS_CHANGED" ) then
		if ( arg1 == self.unit ) then
			if ( UnitLeadsAnyGroup(self.unit) ) then
				self.leaderIcon:Show();
			else
				self.leaderIcon:Hide();
			end
		end
	elseif ( event == "GROUP_ROSTER_UPDATE" ) then
		AededUITargetFrame_Update(self);
		if (self.unit == "focus") then
			-- If this is the focus frame, clear focus if the unit no longer exists
			--[[
			if (not UnitExists(self.unit)) then
				ClearFocus();
			end
			--]]
		else
			if ( self.totFrame ) then
				AededUITargetofTarget_Update(self.totFrame);
			end
			AededUITargetFrame_CheckFaction(self);
		end
	elseif ( event == "RAID_TARGET_UPDATE" ) then
		AededUITargetFrame_UpdateRaidTargetIcon(self);
	elseif ( event == "PLAYER_FOCUS_CHANGED" ) then
		if ( UnitExists(self.unit) ) then
			AededUITargetFrame_Update(self);
			AededUITargetFrame_UpdateRaidTargetIcon(self);
		end
		CloseDropDownMenus();
	end
end
--[[
function AededUITargetFrame_OnVariablesLoaded()
	AededUITargetFrame_SetLocked(not TARGET_FRAME_UNLOCKED);
	AededUITargetFrame_UpdateBuffsOnTop();

	AededUIFocusFrame_SetSmallSize(not GetCVarBool("fullSizeAededUIFocusFrame"));
	AededUIFocusFrame_UpdateBuffsOnTop();
end
--]]
function AededUITargetFrame_OnHide (self)
	PlaySound(SOUNDKIT.INTERFACE_SOUND_LOST_TARGET_UNIT);
	CloseDropDownMenus();
end

function AededUITargetFrame_CheckLevel (self)
	local targetEffectiveLevel = UnitLevel(self.unit);

	if ( UnitIsCorpse(self.unit) ) then
		self.levelText:Hide();
		self.highLevelTexture:Show();
	elseif ( targetEffectiveLevel > 0 ) then
		-- Normal level target
		self.levelText:SetText(targetEffectiveLevel);
		-- Color level number
		if ( UnitCanAttack("player", self.unit) ) then
			local color = GetCreatureDifficultyColor(targetEffectiveLevel);
			self.levelText:SetVertexColor(color.r, color.g, color.b);
		else
			self.levelText:SetVertexColor(1.0, 0.82, 0.0);
		end

		if ( self.isBossFrame ) then
			AededUIBossTargetFrame_UpdateLevelTextAnchor(self, targetEffectiveLevel);
		else
			AededUITargetFrame_UpdateLevelTextAnchor(self, targetEffectiveLevel);
		end

		self.levelText:Show();
		self.highLevelTexture:Hide();
	else
		-- Target is too high level to tell
		self.levelText:Hide();
		self.highLevelTexture:Show();
	end
end

--This is overwritten in LocalizationPost for different languages.
function AededUITargetFrame_UpdateLevelTextAnchor (self, targetLevel)
	if ( targetLevel >= 100 ) then
		self.levelText:SetPoint("CENTER", 62, -16);
	else
		self.levelText:SetPoint("CENTER", 63, -16);
	end
end

--This is overwritten in LocalizationPost for different languages.
function AededUIBossTargetFrame_UpdateLevelTextAnchor (self, targetLevel)
	if ( targetLevel >= 100 ) then
		self.levelText:SetPoint("CENTER", 11, -16);
	else
		self.levelText:SetPoint("CENTER", 12, -16);
	end
end

function AededUITargetFrame_CheckFaction (self)
	if ( not UnitPlayerControlled(self.unit) and UnitIsTapDenied(self.unit) ) then
		self.nameBackground:SetVertexColor(0, 0, 0, 0.5);
		if ( self.portrait ) then
			self.portrait:SetVertexColor(0.5, 0.5, 0.5);
		end
	else
		self.nameBackground:SetVertexColor(0, 0, 0, 0.5);
		if ( self.portrait ) then
			self.portrait:SetVertexColor(1.0, 1.0, 1.0);
		end
	end
end

function AededUITargetFrame_CheckClassification (self, forceNormalTexture)
	local classification = UnitClassification(self.unit);
	self.nameBackground:Show();
	self.manabar.pauseUpdates = false;
	self.manabar:Show();
	AededUITextStatusBar_UpdateTextString(self.manabar);

	if ( forceNormalTexture ) then
		self.borderTexture:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame");
	elseif ( classification == "minus" ) then
		self.borderTexture:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Minus");
		self.nameBackground:Hide();
		self.manabar.pauseUpdates = true;
		self.manabar:Hide();
		self.manabar.TextString:Hide();
		self.manabar.LeftText:Hide();
		self.manabar.RightText:Hide();
		forceNormalTexture = true;
	elseif ( classification == "worldboss" or classification == "elite" ) then
		self.borderTexture:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Elite");
	elseif ( classification == "rareelite" ) then
		self.borderTexture:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Rare-Elite");
	elseif ( classification == "rare" ) then
		self.borderTexture:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Rare");
	else
		self.borderTexture:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame");
		forceNormalTexture = true;
	end

	if ( forceNormalTexture ) then
		self.haveElite = nil;
		if ( classification == "minus" ) then
			self.Background:SetSize(119,12);
			self.Background:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 7, 47);
		else
			self.Background:SetSize(119,25);
			self.Background:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 7, 35);
		end
	else
		self.haveElite = true;
		AededUITargetFrameBackground:SetSize(119,41);
		self.Background:SetSize(119,25);
		self.Background:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 7, 35);
	end
end

function AededUITargetFrame_CheckDead (self)
	if ( (UnitHealth(self.unit) <= 0) and UnitIsConnected(self.unit) ) then
		if ( UnitIsUnconscious(self.unit) ) then
			self.unconsciousText:Show();
			self.deadText:Hide();
		else
			self.unconsciousText:Hide();
			self.deadText:Show();
		end
	else
		self.deadText:Hide();
		self.unconsciousText:Hide();
	end
end

function AededUITargetFrame_OnUpdate (self, elapsed)
	if ( self.totFrame and self.totFrame:IsShown() ~= UnitExists(self.totFrame.unit) ) then
		AededUITargetofTarget_Update(self.totFrame);
	end
end

local function UpdateBuffAnchor(self, buffName, index, numDebuffs, anchorIndex, size, OffsetX, OffsetY)
	local buff = _G[buffName..index];
	if ( index == 1 ) then
		if ( UnitIsFriend("player", self.unit) or numDebuffs == 0 ) then
			buff:SetPoint("TOPLEFT", self, "BOTTOMLEFT", AURA_START_X, AURA_START_Y);
		else
			-- -AURA_OFFSET + 1 because above it are larger debuffs
			buff:SetPoint("TOPLEFT", self.debuffs, "BOTTOMLEFT", 0, -OffsetY);
		end
		self.buffs:SetPoint("TOPLEFT", buff, "TOPLEFT", 0, 0);
		self.buffs:SetPoint("BOTTOMLEFT", buff, "BOTTOMLEFT", 0, -OffsetY); --??
		self.spellbarAnchor = buff;
	elseif ( anchorIndex ~= (index-1) ) then
		-- anchor index is not the previous index...must be a new row
		buff:SetPoint("TOPLEFT", _G[buffName..anchorIndex], "BOTTOMLEFT", 0, -OffsetY);
		self.buffs:SetPoint("BOTTOMLEFT", buff, "BOTTOMLEFT", 0, -OffsetY);
		self.spellbarAnchor = buff;
	else
		-- anchor index is the previous index
		buff:SetPoint("TOPLEFT", _G[buffName..anchorIndex], "TOPRIGHT", OffsetX, 0);
	end
	buff:SetWidth(size);
	buff:SetHeight(size);
end

local function UpdateDebuffAnchor(self, debuffName, index, numBuffs, anchorIndex, size, OffsetX, OffsetY)
	local debuff = _G[debuffName..index];
	local isFriend = UnitIsFriend("player", self.unit);
	if ( index == 1 ) then
		if ( isFriend and numBuffs > 0 ) then
			-- unit is friendly and there are buffs...debuffs start on bottom
			debuff:SetPoint("TOPLEFT", self.buffs, "BOTTOMLEFT", 0, -OffsetY);
		else
			-- unit is not friendly or there are no buffs...debuffs start on top
			debuff:SetPoint("TOPLEFT", self, "BOTTOMLEFT", AURA_START_X, AURA_START_Y);
		end
		self.debuffs:SetPoint("TOPLEFT", debuff, "TOPLEFT", 0, 0);
		--AURA_OFFSET
		self.debuffs:SetPoint("BOTTOMLEFT", debuff, "BOTTOMLEFT", 0, -OffsetY);
		if ( ( isFriend ) or ( not isFriend and numBuffs == 0) ) then
			self.spellbarAnchor = debuff;
		end
	elseif ( anchorIndex ~= (index-1) ) then
		-- anchor index is not the previous index...must be a new row
		debuff:SetPoint("TOPLEFT", _G[debuffName..anchorIndex], "BOTTOMLEFT", 0, -OffsetY);
		self.debuffs:SetPoint("BOTTOMLEFT", debuff, "BOTTOMLEFT", 0, -OffsetY);
		if ( ( isFriend ) or ( not isFriend and numBuffs == 0) ) then
			self.spellbarAnchor = debuff;
		end
	else
		-- anchor index is the previous index
		debuff:SetPoint("TOPLEFT", _G[debuffName..(index-1)], "TOPRIGHT", OffsetX, 0);
	end
	-- Resize
	debuff:SetWidth(size);
	debuff:SetHeight(size);
	
	local debuffFrame =_G[debuffName..index.."Border"];
	
	debuffFrame:SetWidth(size+2);
	debuffFrame:SetHeight(size+2);
end

function AededUITargetFrame_UpdateAuras(self)

	local frame, frameName;
	local lowrank, lowrankName;
	local frameIcon, frameCount, frameCooldown;
	local numBuffs = 0;
	local playerIsTarget = UnitIsUnit(PlayerFrame.unit, self.unit);
	local selfName = self:GetName();

	for i = 1, MAX_TARGET_BUFFS do 
        local buffName, icon, count, _, duration, expirationTime, caster, _, _, spellId, _, _, _, nameplateShowAll = UnitBuff(self.unit, i, nil);
		if (buffName) then
			if ( ( icon and ( not self.maxBuffs or i <= self.maxBuffs )) and not Buff_Filter[buffName] ) then
				numBuffs = numBuffs + 1;
				frameName = selfName.."Buff"..(numBuffs);
				frame = _G[frameName];	
				if ( not frame ) then
					if ( not icon ) then
						break;
					else
						frame = CreateFrame("Button", frameName, self, "AededUITargetBuffFrameTemplate");
						frame.unit = self.unit;
					end
				end
				
				local _, rank = GetSpellInfo(spellId)
				frame:SetID(i);
                -- set the icon
				frameIcon = _G[frameName.."Icon"];
				frameIcon:SetTexture(icon);

					
				-- Handle cooldowns
				frameCooldown = _G[frameName.."Cooldown"];
				if duration and (duration < 599) then
					CooldownFrame_Set(frameCooldown, expirationTime - duration, duration + 0.05, duration > 0, false);
				else
					CooldownFrame_Clear(frameCooldown);
				end
				
				-- set the count
				frameCount = _G[frameName.."Count"];
					
				if ( count > 1 ) then
					frameCount:SetText(count);
					frameCount:Show();
				else
					frameCount:Hide();
				end
				
				frame:ClearAllPoints();
				frame:Show();
				
				if Buff_Filter_Lowrank[name] and rank then
					lowrankName = "lowrank_string_"..i
					lowrank = _G[lowrankName]
					if ((string.find(rank, "1") or string.find(rank, "2")))then
						if not lowrank then
							local lowrank_string = frame:CreateFontString(lowrankName, "OVERLAY")
							lowrank:SetFont("Fonts\\FRIZQT__.TTF", 6.5, "OUTLINE")
							lowrank_string:ClearAllPoints()
							lowrank_string:SetPoint("TOPLEFT", frameName, 0.75, 0.75);
							lowrank_string:SetTextColor(1, 0, 0);
						end
						lowrank:SetText("x")
						lowrank:Show()
					else
						if lowrank then
							lowrank:Hide()
						end
					end
				end	
            end
        else
            break;
        end
	end

	for i = numBuffs + 1, MAX_TARGET_BUFFS do
		local frame = _G[selfName.."Buff"..i];
		if ( frame ) then
			frame:Hide();
		else
			break;
		end
	end

	local color;
	local frameBorder;
	local numDebuffs = 0;

	local frameNum = 1;
	local index = 1;

	local maxDebuffs = self.maxDebuffs or MAX_TARGET_DEBUFFS;
	while ( frameNum <= maxDebuffs and index <= maxDebuffs ) do
	    local debuffName, icon, count, debuffType, duration, expirationTime, caster, _, _, _, _, _, _, nameplateShowAll = UnitDebuff(self.unit, index, "INCLUDE_NAME_PLATE_ONLY");
		if ( debuffName ) then
			if ( icon and not Debuff_Filter[debuffName] ) then
				local _, rank = GetSpellInfo(spellId)
				numDebuffs = numDebuffs + 1;
				frameName = selfName.."Debuff"..numDebuffs;
				frame = _G[frameName];
					if ( not frame ) then
						frame = CreateFrame("Button", frameName, self, "AededUITargetDebuffFrameTemplate");
						frame.unit = self.unit;
					end
					
					frame:SetID(index);

					-- set the icon
					frameIcon = _G[frameName.."Icon"];
					frameIcon:SetTexture(icon);

					-- set the count
					frameCount = _G[frameName.."Count"];
	
					if ( count > 1 ) then
						frameCount:SetText(count);
						frameCount:Show();
					else
						frameCount:Hide();
					end

					-- Handle cooldowns
					frameCooldown = _G[frameName.."Cooldown"];
					if duration and (duration < 600) then
						CooldownFrame_Set(frameCooldown, expirationTime - duration, duration + 0.05 , duration > 0, true);
					else
						frameCooldown:Clear()
					end
					-- set debuff type color
					if ( debuffType ) then
						color = DebuffTypeColor[debuffType];
					else
						color = DebuffTypeColor["none"];
					end
					frameBorder = _G[frameName.."Border"];
					frameBorder:SetVertexColor(color.r, color.g, color.b);

					frame:ClearAllPoints();
					frame:Show();

					frameNum = frameNum + 1;
					
					if Debuff_Filter_Lowrank[name] and rank then
						lowrankName = "lowrank_string_"..i
						lowrank = _G[lowrankName]
						if ((string.find(rank, "1") or string.find(rank, "2"))) then
							if not lowrank then
								local lowrank_string = frame:CreateFontString(lowrankName, "OVERLAY")
								lowrank:SetFont("Fonts\\FRIZQT__.TTF", 6.5, "OUTLINE")
								lowrank_string:ClearAllPoints()
								lowrank_string:SetPoint("TOPLEFT", frameName, 0.75, 0.75);
								lowrank_string:SetTextColor(1, 0, 0);
							end
							lowrank:SetText("x")
							lowrank:Show()
						else
							if lowrank then
								lowrank:Hide()
							end
						end
					end	
			end
		else
			break;
		end
		index = index + 1;
	end

	for i = frameNum, MAX_TARGET_DEBUFFS do
		local frame = _G[selfName.."Debuff"..i];
		if ( frame ) then
			frame:Hide();
		else
			break;
		end
	end

	self.auraRows = 0;

	local haveTargetofTarget;
	if ( self.totFrame ) then
		haveTargetofTarget = self.totFrame:IsShown();
	end
	self.spellbarAnchor = nil;
	
	AededUITargetFrame_UpdateBuffPositions(self, selfName.."Buff", numBuffs, numDebuffs, UpdateBuffAnchor, AURA_ROW_WIDTH_BUFF, 3);

	AededUITargetFrame_UpdateDebuffPositions(self, selfName.."Debuff", numDebuffs, numBuffs, UpdateDebuffAnchor, AURA_ROW_WIDTH, 3);

	if ( self.spellbar ) then
		AededUITarget_Spellbar_AdjustPosition(self.spellbar);
	end
end

--
--		Hide debuffs on mobs cast by players other than me and aren't flagged to show to entire party on nameplates.
--
function AededUITargetFrame_ShouldShowDebuffs(unit, caster, nameplateShowAll, casterIsAPlayer)
	if (GetCVarBool("noBuffDebuffFilterOnTarget")) then
		return true;
	end

	if (nameplateShowAll) then
		return true;
	end

	if (caster and (UnitIsUnit("player", caster) or UnitIsOwnerOrControllerOfUnit("player", caster))) then
		return true;
	end

	if (UnitIsUnit("player", unit)) then
		return true;
	end

	local targetIsFriendly = not UnitCanAttack("player", unit);
	local targetIsAPlayer =  UnitIsPlayer(unit);
	local targetIsAPlayerPet = UnitIsOtherPlayersPet(unit);

	if (not targetIsAPlayer and not targetIsAPlayerPet and not targetIsFriendly and casterIsAPlayer) then
        return false;
    end

    return true;
end


function AededUITargetFrame_UpdateDebuffPositions(self, auraName, numAuras, numOppositeAuras, updateFunc, maxRowWidth, offsetX)
	-- a lot of this complexity is in place to allow the auras to wrap around the target of target frame if it's shown

	-- Position auras
	local size = DEBUFF_AURA_SIZE
	local offsetX = 2.5;
	local offsetY = 2.5;
	-- current width of a row, increases as auras are added and resets when a new aura's width exceeds the max row width
	local rowWidth = 0;
	local firstBuffOnRow = 1;
	for i=1, numAuras do
		-- update size and offset info based on large aura status
		

		-- anchor the current aura
		if ( i == 1 ) then
			rowWidth = 3*(size + offsetX);
			self.auraRows = self.auraRows + 1;
		else
			rowWidth = rowWidth + size + offsetX;
		end
		if ( rowWidth > maxRowWidth ) then
			-- this aura would cause the current row to exceed the max row width, so make this aura
			-- the start of a new row instead
			updateFunc(self, auraName, i, numOppositeAuras, firstBuffOnRow, size, offsetX, offsetY);

			rowWidth = size;
			self.auraRows = self.auraRows + 1;
			firstBuffOnRow = i;
		

			if ( self.auraRows > NUM_TOT_AURA_ROWS ) then
				-- if we exceed the number of tot rows, then reset the max row width
				-- note: don't have to check if we have tot because AURA_ROW_WIDTH is the default anyway
				maxRowWidth = AURA_ROW_WIDTH;
			end
		else
			updateFunc(self, auraName, i, numOppositeAuras, i - 1, size, offsetX, offsetY);
		end
	end
end

function AededUITargetFrame_UpdateBuffPositions(self, auraName, numAuras, numOppositeAuras, updateFunc, maxRowWidth, offsetX)
	-- a lot of this complexity is in place to allow the auras to wrap around the target of target frame if it's shown

	-- Position auras
	local size = BUFF_AURA_SIZE
	local offsetX = 1;
	local offsetY = 1;
	-- current width of a row, increases as auras are added and resets when a new aura's width exceeds the max row width
	local rowWidth = 0;
	local firstBuffOnRow = 1;
	for i=1, numAuras do
		-- update size and offset info based on large aura status
		

		-- anchor the current aura
		if ( i == 1 ) then
			rowWidth = 2*(size + offsetX);
			self.auraRows = self.auraRows + 1;
		else
			rowWidth = rowWidth + size + offsetX;
		end
		if ( rowWidth > maxRowWidth ) then
			-- this aura would cause the current row to exceed the max row width, so make this aura
			-- the start of a new row instead
			updateFunc(self, auraName, i, numOppositeAuras, firstBuffOnRow, size, offsetX, offsetY);

			rowWidth = size;
			self.auraRows = self.auraRows + 1;
			firstBuffOnRow = i;
			

			if ( self.auraRows > NUM_TOT_AURA_ROWS ) then
				-- if we exceed the number of tot rows, then reset the max row width
				-- note: don't have to check if we have tot because AURA_ROW_WIDTH is the default anyway
				maxRowWidth = AURA_ROW_WIDTH_BUFF;
			end
		else
			updateFunc(self, auraName, i, numOppositeAuras, i - 1, size, offsetX, offsetY);
		end
	end
end

function AededUITargetFrame_UpdateBuffAnchor(self, buffName, index, numDebuffs, anchorIndex, size, offsetX, offsetY)
	--For mirroring vertically
	local point, relativePoint;
	local startY, auraOffsetY;

	point = "TOP";
	relativePoint="BOTTOM";
	startY = AURA_START_Y;
	auraOffsetY = AURA_OFFSET_Y;

	local buff = _G[buffName..index];
	if ( index == 1 ) then
		if ( UnitIsFriend("player", self.unit) or numDebuffs == 0 ) then
			-- unit is friendly or there are no debuffs...buffs start on top
			buff:SetPoint(point.."LEFT", self, relativePoint.."LEFT", AURA_START_X, startY);
		else
			-- unit is not friendly and we have debuffs...buffs start on bottom
			buff:SetPoint(point.."LEFT", self.debuffs, relativePoint.."LEFT", 0, -offsetY);
		end
		self.buffs:SetPoint(point.."LEFT", buff, point.."LEFT", 0, 0);
		self.buffs:SetPoint(relativePoint.."LEFT", buff, relativePoint.."LEFT", 0, -auraOffsetY);
		self.spellbarAnchor = buff;
	elseif ( anchorIndex ~= (index-1) ) then
		-- anchor index is not the previous index...must be a new row
		buff:SetPoint(point.."LEFT", _G[buffName..anchorIndex], relativePoint.."LEFT", 0, -offsetY);
		self.buffs:SetPoint(relativePoint.."LEFT", buff, relativePoint.."LEFT", 0, -auraOffsetY);
		self.spellbarAnchor = buff;
	else
		-- anchor index is the previous index
		buff:SetPoint(point.."LEFT", _G[buffName..anchorIndex], point.."RIGHT", offsetX, 0);
	end

	-- Resize
	buff:SetWidth(size);
	buff:SetHeight(size);
end

function AededUITargetFrame_UpdateDebuffAnchor(self, debuffName, index, numBuffs, anchorIndex, size, offsetX, offsetY)
	local buff = _G[debuffName..index];
	local isFriend = UnitIsFriend("player", self.unit);

	--For mirroring vertically
	local point, relativePoint;
	local startY, auraOffsetY;

	point = "TOP";
	relativePoint="BOTTOM";
	startY = AURA_START_Y;
	auraOffsetY = AURA_OFFSET_Y;


	if ( index == 1 ) then
		if ( isFriend and numBuffs > 0 ) then
			-- unit is friendly and there are buffs...debuffs start on bottom
			buff:SetPoint(point.."LEFT", self.buffs, relativePoint.."LEFT", 0, -offsetY);
		else
			-- unit is not friendly or there are no buffs...debuffs start on top
			buff:SetPoint(point.."LEFT", self, relativePoint.."LEFT", AURA_START_X, startY);
		end
		self.debuffs:SetPoint(point.."LEFT", buff, point.."LEFT", 0, 0);
		self.debuffs:SetPoint(relativePoint.."LEFT", buff, relativePoint.."LEFT", 0, -auraOffsetY);
		if ( ( isFriend ) or ( not isFriend and numBuffs == 0) ) then
			self.spellbarAnchor = buff;
		end
	elseif ( anchorIndex ~= (index-1) ) then
		-- anchor index is not the previous index...must be a new row
		buff:SetPoint(point.."LEFT", _G[debuffName..anchorIndex], relativePoint.."LEFT", 0, -offsetY);
		self.debuffs:SetPoint(relativePoint.."LEFT", buff, relativePoint.."LEFT", 0, -auraOffsetY);
		if ( ( isFriend ) or ( not isFriend and numBuffs == 0) ) then
			self.spellbarAnchor = buff;
		end
	else
		-- anchor index is the previous index
		buff:SetPoint(point.."LEFT", _G[debuffName..(index-1)], point.."RIGHT", offsetX, 0);
	end

	-- Resize
	buff:SetWidth(size);
	buff:SetHeight(size);
	local debuffFrame =_G[debuffName..index.."Border"];
	debuffFrame:SetWidth(size+2);
	debuffFrame:SetHeight(size+2);
end

function AededUITargetHealthCheck (self)
	if ( UnitIsPlayer(self.unit) ) then
		local parent = self:GetParent();
		if ( parent.portrait ) then
			if ( UnitIsDead(self.unit) ) then
				parent.portrait:SetVertexColor(0.35, 0.35, 0.35, 1.0);
			elseif ( UnitIsGhost(self.unit) ) then
				parent.portrait:SetVertexColor(0.35, 0.35, 0.35, 1.0);
			else
				parent.portrait:SetVertexColor(1.0, 1.0, 1.0, 1.0);
			end
		end
	end
end

function AededUITargetFrameDropDown_Initialize (self)
	local menu;
	local name;
	local id = nil;
	if ( UnitIsUnit("target", "player") ) then
		menu = "SELF";
	elseif ( UnitIsUnit("target", "vehicle") ) then
		-- NOTE: vehicle check must come before pet check for accuracy's sake because
		-- a vehicle may also be considered your pet
		menu = "VEHICLE";
	elseif ( UnitIsUnit("target", "pet") ) then
		menu = "PET";
	elseif ( UnitIsOtherPlayersPet("target") ) then
		menu = "OTHERPET";
	elseif ( UnitIsPlayer("target") ) then
		id = UnitInRaid("target");
		if ( id ) then
			menu = "RAID_PLAYER";
		elseif ( UnitInParty("target") ) then
			menu = "PARTY";
		elseif ( UnitCanCooperate("player", "target") ) then
			menu = "PLAYER";
		else
			menu = "ENEMY_PLAYER"
		end
	else
		menu = "TARGET";
		name = RAID_TARGET_ICON;
	end
	if ( menu ) then
		AededUIUnitPopup_ShowMenu(self, menu, "target", name, id);
	end
end

-- Raid target icon function
RAID_TARGET_ICON_DIMENSION = 64;
RAID_TARGET_TEXTURE_DIMENSION = 256;
RAID_TARGET_TEXTURE_COLUMNS = 4;
RAID_TARGET_TEXTURE_ROWS = 4;
function AededUITargetFrame_UpdateRaidTargetIcon (self)
	local index = GetRaidTargetIndex(self.unit);
	if ( index ) then
		SetRaidTargetIconTexture(self.raidTargetIcon, index);
		self.raidTargetIcon:Show();
	else
		self.raidTargetIcon:Hide();
	end
end

function SetRaidTargetIconTexture (texture, raidTargetIconIndex)
	raidTargetIconIndex = raidTargetIconIndex - 1;
	local left, right, top, bottom;
	local coordIncrement = RAID_TARGET_ICON_DIMENSION / RAID_TARGET_TEXTURE_DIMENSION;
	left = mod(raidTargetIconIndex , RAID_TARGET_TEXTURE_COLUMNS) * coordIncrement;
	right = left + coordIncrement;
	top = floor(raidTargetIconIndex / RAID_TARGET_TEXTURE_ROWS) * coordIncrement;
	bottom = top + coordIncrement;
	texture:SetTexCoord(left, right, top, bottom);
end

function SetRaidTargetIcon (unit, index)
	if ( GetRaidTargetIndex(unit) and GetRaidTargetIndex(unit) == index ) then
		SetRaidTarget(unit, 0);
	else
		SetRaidTarget(unit, index);
	end
end

function AededUITargetFrame_CreateTargetofTarget(self, unit)
	--local parent = self:GetParent()
	local thisName = self:GetName().."ToT";
	local frame = CreateFrame("BUTTON", thisName, self, "AededUIToTFrameTemplate");
	
	self.totFrame = frame;
	AededUIUnitFrame_Initialize(frame, unit, _G[thisName.."TextureFrameName"], _G[thisName.."Portrait"],
						 _G[thisName.."HealthBar"], nil,
						 _G[thisName.."ManaBar"], nil);
	AededUISetTextStatusBarTextZeroText(frame.healthbar, DEAD);
	frame.deadText = _G[thisName.."TextureFrameDeadText"];
	frame.unconsciousText = _G[thisName.."TextureFrameUnconsciousText"];
	SecureUnitButton_OnLoad(frame, unit);
	
							RegisterUnitWatch(frame, false);
						frame:SetScale(0.675);
end

function AededUITargetFrame_CreateTargetofFocus(self, unit)
	--local parent = self:GetParent()
	local thisName = self:GetName().."ToT";
	local frame = CreateFrame("BUTTON", thisName, self, "AededUIToTFocusFrameTemplate");
	
	self.totFrame = frame;
	AededUIUnitFrame_Initialize(frame, unit, _G[thisName.."TextureFrameName"], _G[thisName.."Portrait"],
						 _G[thisName.."HealthBar"], nil,
						 _G[thisName.."ManaBar"], nil);
	AededUISetTextStatusBarTextZeroText(frame.healthbar, DEAD);
	frame.deadText = _G[thisName.."TextureFrameDeadText"];
	frame.unconsciousText = _G[thisName.."TextureFrameUnconsciousText"];
	SecureUnitButton_OnLoad(frame, unit);
	
							RegisterUnitWatch(frame, false);
						frame:SetScale(0.75);
end


function AededUITargetofTarget_OnHide(self)
	AededUITargetFrame_UpdateAuras(self:GetParent());
end

function AededUITargetofTarget_Update(self, elapsed)
	local show;
	local parent = self:GetParent();
	if ( SHOW_TARGET_OF_TARGET == "1" and UnitExists(parent.unit) and UnitExists(self.unit) and ( UnitHealth(parent.unit) > 0 ) ) then
		if ( not self:IsShown() ) then
			if ( parent.spellbar ) then
				parent.haveToT = true;
				AededUITarget_Spellbar_AdjustPosition(parent.spellbar);
			end
		end
		if ( UnitIsUnit(PlayerFrame.unit, parent.unit) ) then
			self:SetAlpha(0)
		else
			self:SetAlpha(1)
		end
		AededUIUnitFrame_Update(self);
		AededUITargetofTarget_CheckDead(self);
		AededUITargetofTargetHealthCheck(self);
		AededUIRefreshDebuffsSmall(self, self.unit, nil, nil, true);
	else
		if ( self:IsShown() ) then
			if ( parent.spellbar ) then
				parent.haveToT = nil;
				AededUITarget_Spellbar_AdjustPosition(parent.spellbar);
			end
		end
	end
end

function AededUITargetofTarget_CheckDead(self)
	if ( (UnitHealth(self.unit) <= 0) and UnitIsConnected(self.unit) ) then
		self.background:SetAlpha(0.9);
		if ( UnitIsUnconscious(self.unit) ) then
			self.unconsciousText:Show();
			self.deadText:Hide();
		else
			self.unconsciousText:Hide();
			self.deadText:Show();
		end
	else
		self.background:SetAlpha(1);
		self.deadText:Hide();
		self.unconsciousText:Hide();
	end
end

function AededUITargetofTargetHealthCheck(self)
	if ( UnitIsPlayer(self.unit) ) then
		if ( UnitIsDead(self.unit) ) then
			self.portrait:SetVertexColor(0.35, 0.35, 0.35, 1.0);
		elseif ( UnitIsGhost(self.unit) ) then
			self.portrait:SetVertexColor(0.2, 0.2, 0.75, 1.0);
		else
			self.portrait:SetVertexColor(1.0, 1.0, 1.0, 1.0);
		end
	else
		self.portrait:SetVertexColor(1.0, 1.0, 1.0, 1.0);
	end
end

function AededUITargetFrame_CreateSpellbar(self, event, boss)
	local name = self:GetName().."SpellBar";
	local spellbar;
	if ( boss ) then
		spellbar = CreateFrame("STATUSBAR", name, self, "AededUIBossSpellBarTemplate");
	else
		spellbar = CreateFrame("STATUSBAR", name, self, "AededUITargetSpellBarTemplate");
		spellbar:SetScale(0.9)
	end
	spellbar.boss = boss;
	spellbar:SetFrameLevel(_G[self:GetName().."TextureFrame"]:GetFrameLevel() - 1);
	self.spellbar = spellbar;
	self.auraRows = 0;
	spellbar:RegisterEvent("CVAR_UPDATE");
	spellbar:RegisterEvent("VARIABLES_LOADED");

	AededUICastingBarFrame_SetUnit(spellbar, self.unit, false, true);
	if ( event ) then
		spellbar.updateEvent = event;
		spellbar:RegisterEvent(event);
	end

	-- check to see if the castbar should be shown
	if ( GetCVar("showTargetCastbar") == "0") then
		spellbar.showCastbar = false;
	end
end

function AededUITarget_Spellbar_OnEvent(self, event, ...)

	local arg1 = ...

	--	Check for target specific events
	if ( (event == "VARIABLES_LOADED") or ((event == "CVAR_UPDATE") and (arg1 == "SHOW_TARGET_CASTBAR")) ) then
		if ( GetCVar("showTargetCastbar") == "0") then
			self.showCastbar = false;
		else
			self.showCastbar = true;
		end

		if ( not self.showCastbar ) then
			self:Hide();
		elseif ( self.casting or self.channeling ) then
			self:Show();
		end
		return;
	elseif ( event == self.updateEvent ) then
		-- check if the new target is casting a spell
		local nameChannel  = UnitChannelInfo(self.unit);
		local nameSpell  = UnitCastingInfo(self.unit);
		if ( nameChannel ) then
			event = "UNIT_SPELLCAST_CHANNEL_START";
			arg1 = self.unit;
		elseif ( nameSpell ) then
			event = "UNIT_SPELLCAST_START";
			arg1 = self.unit;
		else
			self.casting = nil;
			self.channeling = nil;
			self:SetMinMaxValues(0, 0);
			self:SetValue(0);
			self:Hide();
			return;
		end
		-- The position depends on the classification of the target
		AededUITarget_Spellbar_AdjustPosition(self);
	end
	AededUICastingBarFrame_OnEvent(self, event, arg1, select(2, ...));
end

function AededUITarget_Spellbar_AdjustPosition(self)
	local parentFrame = self:GetParent();
	if ( self.boss ) then
		self:SetPoint("TOPLEFT", parentFrame, "BOTTOMLEFT", 25, 10 );
	elseif ( parentFrame.haveToT ) then
		if ( parentFrame.buffsOnTop or parentFrame.auraRows <= 1 ) then
			self:SetPoint("TOPLEFT", parentFrame, "BOTTOMLEFT", 25, -21 );
		else
			self:SetPoint("TOPLEFT", parentFrame.spellbarAnchor, "BOTTOMLEFT", 20, -15);
		end
	elseif ( parentFrame.haveElite ) then
		if ( parentFrame.buffsOnTop or parentFrame.auraRows <= 1 ) then
			self:SetPoint("TOPLEFT", parentFrame, "BOTTOMLEFT", 25, -5 );
		else
			self:SetPoint("TOPLEFT", parentFrame.spellbarAnchor, "BOTTOMLEFT", 20, -15);
		end
	else
		if ( (not parentFrame.buffsOnTop) and parentFrame.auraRows > 0 ) then
			self:SetPoint("TOPLEFT", parentFrame.spellbarAnchor, "BOTTOMLEFT", 20, -15);
		else
			self:SetPoint("TOPLEFT", parentFrame, "BOTTOMLEFT", 25, 7 );
		end
	end
end

function AededUITargetFrame_OnDragStart(self)
	self:StartMoving();
	self:SetUserPlaced(true);
	self:SetClampedToScreen(true);
end

function AededUITargetFrame_OnDragStop(self)
	self:StopMovingOrSizing();
end

function AededUITargetFrame_SetLocked(locked)
	TARGET_FRAME_UNLOCKED = not locked;
	if ( locked ) then
		AededUITargetFrame:RegisterForDrag();	--Unregister all buttons.
	else
		AededUITargetFrame:RegisterForDrag("LeftButton");
	end
end

function AededUITargetFrame_ResetUserPlacedPosition()
	AededUITargetFrame:ClearAllPoints();
	AededUITargetFrame:SetUserPlaced(false);
	AededUITargetFrame:SetClampedToScreen(false);
	AededUITargetFrame_SetLocked(true);
	UIParent_UpdateTopFramePositions();
end

function AededUITargetFrame_UpdateBuffsOnTop()
	if ( TARGET_FRAME_BUFFS_ON_TOP ) then
		AededUITargetFrame.buffsOnTop = true;
	else
		AededUITargetFrame.buffsOnTop = false;
	end
	AededUITargetFrame_UpdateAuras(AededUITargetFrame);
end

-- *********************************************************************************
-- Boss Frames
-- *********************************************************************************

function AededUIBossTargetFrame_OnLoad(self, unit, event)
	self.isBossFrame = true;
	self.noTextPrefix = true;
	self.showLevel = true;
	self.maxBuffs = 0;
	self.maxDebuffs = 0;
	AededUITargetFrame_OnLoad(self, unit, AededUIBossTargetFrameDropDown_Initialize);
	self:RegisterEvent("UNIT_TARGETABLE_CHANGED");
	self.borderTexture:SetTexture("Interface\\TargetingFrame\\UI-UnitFrame-Boss");
	self.levelText:SetPoint("CENTER", 12, select(5, self.levelText:GetPoint("CENTER")));
	self.raidTargetIcon:SetPoint("RIGHT", -90, 0);
	self:SetHitRectInsets(0, 95, 15, 30);
	self:SetScale(0.75);
	if ( event ) then
		self:RegisterEvent(event);
	end
end

function AededUIBossTargetFrameDropDown_Initialize(self)
	AededUIUnitPopup_ShowMenu(self, "BOSS", self:GetParent().unit);
end

-- *********************************************************************************
-- Focus Frame
-- *********************************************************************************

function AededUIFocusFrameDropDown_Initialize(self)
	AededUIUnitPopup_ShowMenu(self, "FOCUS", "focus", SET_FOCUS);
end

FOCUS_FRAME_LOCKED = true;
function AededUIFocusFrame_IsLocked()
	return FOCUS_FRAME_LOCKED;
end

function AededUIFocusFrame_SetLock(locked)
	FOCUS_FRAME_LOCKED = locked;
end

function AededUIFocusFrame_OnDragStart(self, button)
	FOCUS_FRAME_MOVING = false;
	if ( not FOCUS_FRAME_LOCKED ) then
		local cursorX, cursorY = GetCursorPosition();
		self:SetFrameStrata("DIALOG");
		self:StartMoving();
		FOCUS_FRAME_MOVING = true;
	end
end

function AededUIFocusFrame_OnDragStop(self)
	if ( not FOCUS_FRAME_LOCKED and FOCUS_FRAME_MOVING ) then
		self:StopMovingOrSizing();
		self:SetFrameStrata("BACKGROUND");
		if ( self:GetBottom() < 15 + MainMenuBar:GetHeight() ) then
			local anchorX = self:GetLeft();
			local anchorY = 60;
			if ( self.smallSize ) then
				anchorY = 90;	-- empirically determined
			end
			self:SetPoint("BOTTOMLEFT", anchorX, anchorY);
		end
		FOCUS_FRAME_MOVING = false;
	end
end

function AededUIFocusFrame_SetSmallSize(smallSize, onChange)
	if ( smallSize and not AededUIFocusFrame.smallSize ) then
		local x = AededUIFocusFrame:GetLeft();
		local y = AededUIFocusFrame:GetTop();
		AededUIFocusFrame.smallSize = true;
		AededUIFocusFrame.maxBuffs = 0;
		AededUIFocusFrame.maxDebuffs = 8;
		AededUIFocusFrame:SetScale(SMALL_FOCUS_SCALE);
		AededUIFocusFrameToT:SetScale(SMALL_FOCUS_UPSCALE);
		AededUIFocusFrameToT:SetPoint("BOTTOMRIGHT", -13, -17);
		AededUIFocusFrame.TOT_AURA_ROW_WIDTH = 80;	-- not as much room for auras with scaled-up ToT frame
		AededUIFocusFrame.spellbar:SetScale(SMALL_FOCUS_UPSCALE);
		AededUIFocusFrameTextureFrameName:SetFontObject(FocusFontSmall);
		AededUIFocusFrameTextureFrameName:SetWidth(120);
		if ( onChange ) then
			-- the frame needs to be repositioned because anchor offsets get adjusted with scale
			AededUIFocusFrame:ClearAllPoints();
			AededUIFocusFrame:SetPoint("TOPLEFT", x * SMALL_FOCUS_UPSCALE + 29, (y - GetScreenHeight()) * SMALL_FOCUS_UPSCALE - 13);
		end
		AededUIFocusFrame:UnregisterEvent("UNIT_CLASSIFICATION_CHANGED");
		AededUIFocusFrame.showClassification = true;
		AededUIFocusFrame:UnregisterEvent("PLAYER_FLAGS_CHANGED");
		AededUIFocusFrame.showLeader = nil;
		AededUIFocusFrame.leaderIcon:Hide();
		AededUIFocusFrame.showAuraCount = nil;
--		AededUITargetFrame_CheckClassification(AededUIFocusFrame, true);
		AededUITargetFrame_Update(AededUIFocusFrame);
	elseif ( not smallSize and AededUIFocusFrame.smallSize ) then
		local x = AededUIFocusFrame:GetLeft();
		local y = AededUIFocusFrame:GetTop();
		AededUIFocusFrame.smallSize = false;
		AededUIFocusFrame.maxBuffs = nil;
		AededUIFocusFrame.maxDebuffs = nil;
		AededUIFocusFrame:SetScale(LARGE_FOCUS_SCALE);
		AededUIFocusFrameToT:SetScale(LARGE_FOCUS_SCALE);
		AededUIFocusFrameToT:SetPoint("BOTTOMRIGHT", -35, -10);
		AededUIFocusFrame.TOT_AURA_ROW_WIDTH = TOT_AURA_ROW_WIDTH;
		AededUIFocusFrame.spellbar:SetScale(LARGE_FOCUS_SCALE);
		AededUIFocusFrameTextureFrameName:SetFontObject(GameFontNormalSmall);
		AededUIFocusFrameTextureFrameName:SetWidth(100);
		if ( onChange ) then
			-- the frame needs to be repositioned because anchor offsets get adjusted with scale
			AededUIFocusFrame:ClearAllPoints();
			AededUIFocusFrame:SetPoint("TOPLEFT", (x - 29) / SMALL_FOCUS_UPSCALE, (y + 13) / SMALL_FOCUS_UPSCALE - GetScreenHeight());
		end
		AededUIFocusFrame:RegisterEvent("UNIT_CLASSIFICATION_CHANGED");
		AededUIFocusFrame.showClassification = true;
		AededUIFocusFrame:RegisterEvent("PLAYER_FLAGS_CHANGED");
		AededUIFocusFrame.showLeader = true;
		AededUIFocusFrame.showAuraCount = true;
		AededUITargetFrame_Update(AededUIFocusFrame);
	end
end

function AededUIFocusFrame_UpdateBuffsOnTop()
	if ( FOCUS_FRAME_BUFFS_ON_TOP ) then
		AededUIFocusFrame.buffsOnTop = true;
	else
		AededUIFocusFrame.buffsOnTop = false;
	end
	AededUITargetFrame_UpdateAuras(AededUIFocusFrame);
end
