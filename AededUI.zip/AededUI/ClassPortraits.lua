local ClassPortraits=CreateFrame("Frame", nil, UIParent);

local iconPath="Interface\\Addons\\AededUI\\UI-CLASSES-CIRCLES.BLP";

local classIcons = {

	-- UpperLeftx, UpperLefty, LowerLeftx, LowerLefty, UpperRightx, UpperRighty, LowerRightx, LowerRighty

	["WARRIOR"] = {0, 0, 0, 0.25, 0.25, 0, 0.25, 0.25},
	["ROGUE"] = {0.5, 0, 0.5, 0.25, 0.75, 0, 0.75, 0.25},
	["DRUID"] = {0.75, 0, 0.75, 0.25, 1, 0, 1, 0.25},
	["WARLOCK"] = {0.75, 0.25, 0.75, 0.5, 1, 0.25, 1, 0.5},
	["HUNTER"] = {0, 0.25, 0, 0.5, 0.25, 0.25, 0.25, 0.5},
	["PRIEST"] = {0.5, 0.25, 0.5, 0.5, 0.75, 0.25, 0.75, 0.5},
	["PALADIN"] = {0, 0.5, 0, 0.75, 0.25, 0.5, 0.25, 0.75},
	["SHAMAN"] = {0.25, 0.25, 0.25, 0.5, 0.5, 0.25, 0.5, 0.5},
	["MAGE"] = {0.25, 0, 0.25, 0.25, 0.5, 0, 0.5, 0.25}
	
};




hooksecurefunc("SetPortraitTexture", function(portrait, unit)


	if ( portrait:GetName() == "MicroButtonPortrait" ) then
	
		return
		
	end
	
	if (UnitIsPlayer(unit) and portrait and UnitClass(unit))  then

		portrait:SetTexture(iconPath, true);
		portrait:SetTexCoord(unpack(classIcons[select(2, UnitClass(unit))]));
	
	elseif (unit and portrait) then
		
		portrait:SetTexCoord(0,1,0,1);
	
	end

end);

DressUpFrame:HookScript("OnShow", function() 

	DressUpFrameDescriptionText:SetAlpha(0)
	
end)
