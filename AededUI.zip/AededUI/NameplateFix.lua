
--[[
local function GetUnitNameplates()

		for i, frame in ipairs(C_NamePlate.GetNamePlates(issecure())) do
			if frame.namePlateUnitToken and not UnitCanAttack("player", frame.namePlateUnitToken) and not UnitAffectingCombat("player") then
				--frame.namePlateUnitToken = nil;
				--frame.driverFrame = nil;
				--CompactUnitFrame_SetUnit(frame.UnitFrame, nil)
				--print(GetUnitName(frame.namePlateUnitToken, true))
				
				--print(frame:GetName(), "plate", frame.UnitFrame.name)
				local child1, child2, child3, child4 = frame:GetChildren()
				--print(child1:GetName(), frame:GetName(), frame.UnitFrame.name:GetName(), child4)
					frame:Hide()
					frame.UnitFrame.name:Show();
					frame.UnitFrame.name:SetText(GetUnitName(frame.namePlateUnitToken, true))
			
				
			end
		end
		
end




local NameplateFix = CreateFrame("Frame")
NameplateFix:RegisterEvent("NAME_PLATE_CREATED");
NameplateFix:RegisterEvent("UNIT_FACTION");
NameplateFix:RegisterEvent("PLAYER_REGEN_DISABLED");
NameplateFix:RegisterEvent("FORBIDDEN_NAME_PLATE_CREATED");
NameplateFix:RegisterEvent("NAME_PLATE_UNIT_ADDED");
NameplateFix:RegisterEvent("FORBIDDEN_NAME_PLATE_UNIT_ADDED");
NameplateFix:RegisterEvent("NAME_PLATE_UNIT_REMOVED");
NameplateFix:RegisterEvent("FORBIDDEN_NAME_PLATE_UNIT_REMOVED");



NameplateFix:SetScript("OnEvent", function(self, event, ...)

	if event == "NAME_PLATE_CREATED" then
		GetUnitNameplates()
	elseif event == "FORBIDDEN_NAME_PLATE_CREATED" then
		GetUnitNameplates()
	elseif event == "PLAYER_REGEN_DISABLED" then
		GetUnitNameplates()
	elseif event == "NAME_PLATE_UNIT_ADDED" or event == "FORBIDDEN_NAME_PLATE_UNIT_ADDED" then
		GetUnitNameplates()
	elseif event == "NAME_PLATE_UNIT_REMOVED" or event == "FORBIDDEN_NAME_PLATE_UNIT_REMOVED" then
		GetUnitNameplates()
	elseif ( event == "UNIT_FACTION" ) then
		GetUnitNameplates()
	end

end)

hooksecurefunc("CompactUnitFrame_UpdateName", function (frame)
	if frame.UpdateNameOverride and frame:UpdateNameOverride() then
		return;
	end
	
	if ( not ShouldShowName(frame) ) then
	
		frame.name:Hide();
		
	else
		local name = GetUnitName(frame.unit, true);
		if ( C_Commentator.IsSpectating() and name ) then
			local overrideName = C_Commentator.GetPlayerOverrideName(name);
			if overrideName then
				name = overrideName;
			end
		end
		--print(frame:GetName(), "compact")
		frame.name:SetText(name);
		if ( CompactUnitFrame_IsTapDenied(frame) ) then
			-- Use grey if not a player and can't get tap on unit
			frame.name:SetVertexColor(0.5, 0.5, 0.5);
		elseif ( frame.optionTable.colorNameBySelection ) then
			if ( frame.optionTable.considerSelectionInCombatAsHostile and CompactUnitFrame_IsOnThreatListWithPlayer(frame.displayedUnit) ) then
				frame.name:SetVertexColor(1.0, 0.0, 0.0);
			else
				frame.name:SetVertexColor(UnitSelectionColor(frame.unit, frame.optionTable.colorNameWithExtendedColors));
			end
		end
		frame.name:Show();
	end
end)
--]]