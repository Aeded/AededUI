--PET_WARNING_TIME = 55;
--PET_FLASH_ON_TIME = 0.5;
--PET_FLASH_OFF_TIME = 0.5;

function AededUIPetFrame_OnLoad (self)
	self.noTextPrefix = true;

	AededUIPetFrameHealthBar.LeftText = AededUIPetFrameHealthBarTextLeft;
	AededUIPetFrameHealthBar.RightText = AededUIPetFrameHealthBarTextRight;
	AededUIPetFrameManaBar.LeftText = AededUIPetFrameManaBarTextLeft;
	AededUIPetFrameManaBar.RightText = AededUIPetFrameManaBarTextRight;

	AededUIUnitFrame_Initialize(self, "pet", AededUIPetName, AededUIPetPortrait,
						 AededUIPetFrameHealthBar, AededUIPetFrameHealthBarText, 
						 AededUIPetFrameManaBar, AededUIPetFrameManaBarText,
						 AededUIPetFrameFlash, nil, nil,
						 AededUIPetFrameMyHealPredictionBar, AededUIPetFrameOtherHealPredictionBar,
						 AededUIPetFrameTotalAbsorbBar, AededUIPetFrameTotalAbsorbBarOverlay, 
						 AededUIPetFrameOverAbsorbGlow, AededUIPetFrameOverHealAbsorbGlow, AededUIPetFrameHealAbsorbBar,
						 AededUIPetFrameHealAbsorbBarLeftShadow, AededUIPetFrameHealAbsorbBarRightShadow);
	self.attackModeCounter = 0;
	self.attackModeSign = -1;
	AededUIPetFrame_Update(self);
	self:RegisterUnitEvent("UNIT_PET", "player");
	self:RegisterEvent("PET_ATTACK_START");
	self:RegisterEvent("PET_ATTACK_STOP");
	self:RegisterEvent("PET_UI_UPDATE");
	self:RegisterEvent("UNIT_HAPPINESS");
	self:RegisterEvent("UNIT_MAXPOWER");
	self:RegisterUnitEvent("UNIT_COMBAT", "pet", "player");
	self:RegisterUnitEvent("UNIT_AURA", "pet", "player");
	local showmenu = function()
		ToggleDropDownMenu(1, nil, AededUIPetFrameDropDown, "AededUIPetFrame", 44, 8);
	end
	SecureUnitButton_OnLoad(self, "pet", showmenu);
end

function AededUIPetFrame_Update (self, override)
	if ( (not PlayerFrame.animating) or (override) ) then
		if ( UnitIsVisible(self.unit) and PetUsesPetFrame() and not PlayerFrame.vehicleHidesAededUIPet ) then
			if ( self:IsShown() ) then
				AededUIUnitFrame_Update(self);
			end
			--self.flashState = 1;
			--self.flashTimer = PET_FLASH_ON_TIME;
			if ( UnitPowerMax(self.unit) == 0 ) then
				AededUIPetFrameTexture:SetTexture("Interface\\TargetingFrame\\UI-SmallTargetingFrame-NoMana");
				AededUIPetFrameManaBarText:Hide();
			else
				AededUIPetFrameTexture:SetTexture("Interface\\TargetingFrame\\UI-SmallTargetingFrame");
			end
			AededUIPetAttackModeTexture:Hide();

			AededUIPetFrame_SetHappiness();
			RefreshBuffs(self, self.unit, nil, nil);
			AededUIUnitFrame_LoseControl(self);
		end
	end
end

function AededUIPetFrame_OnEvent (self, event, ...)
	AededUIUnitFrame_OnEvent(self, event, ...);
	local arg1, arg2, arg3, arg4, arg5 = ...;
	if ( event == "UNIT_PET" or event == "UNIT_EXITED_VEHICLE" or event == "PET_UI_UPDATE" ) then
		AededUIUnitFrame_SetUnit(self, "pet", AededUIPetFrameHealthBar, AededUIPetFrameManaBar);
		AededUIPetFrame_Update(self);
	elseif ( event == "UNIT_COMBAT" ) then
		if ( arg1 == self.unit ) then
			--CombatFeedback_OnCombatEvent(self, arg2, arg3, arg4, arg5);
		end
	elseif ( event == "UNIT_AURA" ) then
		if ( arg1 == self.unit ) then
			RefreshBuffs(self, self.unit, nil, nil);
			AededUIUnitFrame_LoseControl(self);
		end
	elseif ( event == "PET_ATTACK_START" ) then
		AededUIPetAttackModeTexture:SetVertexColor(1.0, 1.0, 1.0, 1.0);
		AededUIPetAttackModeTexture:Show();
	elseif ( event == "PET_ATTACK_STOP" ) then
		AededUIPetAttackModeTexture:Hide();
	elseif (event == "UNIT_HAPPINESS" ) then
		AededUIPetFrame_SetHappiness();
	elseif (event == "UNIT_MAXPOWER" ) then
		AededUIPetFrame_Update(self);
	end
end

function AededUIPetFrame_OnUpdate (self, elapsed)
	if ( AededUIPetAttackModeTexture:IsShown() ) then
		local alpha = 255;
		local counter = self.attackModeCounter + elapsed;
		local sign    = self.attackModeSign;

		if ( counter > 0.5 ) then
			sign = -sign;
			self.attackModeSign = sign;
		end
		counter = mod(counter, 0.5);
		self.attackModeCounter = counter;

		if ( sign == 1 ) then
			alpha = (55  + (counter * 400)) / 255;
		else
			alpha = (255 - (counter * 400)) / 255;
		end
		AededUIPetAttackModeTexture:SetVertexColor(1.0, 1.0, 1.0, alpha);
	end
	--CombatFeedback_OnUpdate(self, elapsed);
	-- Expiration flash stuff
	--local petTimeRemaining = nil;
	--if ( GetAededUIPetTimeRemaining() ) then
	---	if ( self.flashState == 1 ) then
	--		self:SetAlpha(this.flashTimer/PET_FLASH_ON_TIME);
	--	else
	--		self:SetAlpha((PET_FLASH_OFF_TIME - this.flashTimer)/PET_FLASH_OFF_TIME);
	--	end
	--	petTimeRemaining = GetAededUIPetTimeRemaining() / 1000;
	--end
	--if ( petTimeRemaining and (petTimeRemaining < PET_WARNING_TIME) ) then
	--	AededUIPetFrame.flashTimer = AededUIPetFrame.flashTimer - elapsed;
	--	if ( AededUIPetFrame.flashTimer <= 0 ) then
	--		if ( AededUIPetFrame.flashState == 1 ) then
	--			AededUIPetFrame.flashState = 0;
	--			AededUIPetFrame.flashTimer = PET_FLASH_OFF_TIME;
	--		else
	--			AededUIPetFrame.flashState = 1;
	--			AededUIPetFrame.flashTimer = PET_FLASH_ON_TIME;
	--		end
	--	end
	--end
	
end

function AededUIPetFrame_SetHappiness()
	local happiness, damagePercentage, loyaltyRate = GetPetHappiness();
	local hasAededUIPetUI, isHunterAededUIPet = HasPetUI();
	if ( not happiness or not isHunterAededUIPet ) then
		AededUIPetFrameHappiness:Hide();
		return;	
	end
	AededUIPetFrameHappiness:Show();
	if ( happiness == 1 ) then
		AededUIPetFrameHappinessTexture:SetTexCoord(0.375, 0.5625, 0, 0.359375);
	elseif ( happiness == 2 ) then
		AededUIPetFrameHappinessTexture:SetTexCoord(0.1875, 0.375, 0, 0.359375);
	elseif ( happiness == 3 ) then
		AededUIPetFrameHappinessTexture:SetTexCoord(0, 0.1875, 0, 0.359375);
	end
	AededUIPetFrameHappiness.tooltip = _G["PET_HAPPINESS"..happiness];
	AededUIPetFrameHappiness.tooltipDamage = format(PET_DAMAGE_PERCENTAGE, damagePercentage);
	if ( loyaltyRate < 0 ) then
		AededUIPetFrameHappiness.tooltipLoyalty = _G["LOSING_LOYALTY"];
	elseif ( loyaltyRate > 0 ) then
		AededUIPetFrameHappiness.tooltipLoyalty = _G["GAINING_LOYALTY"];
	else
		AededUIPetFrameHappiness.tooltipLoyalty = nil;
	end
end

function AededUIPetFrameDropDown_OnLoad (self)
	UIDropDownMenu_Initialize(self, AededUIPetFrameDropDown_Initialize, "MENU");
end

function AededUIPetFrameDropDown_Initialize ()
	if ( UnitExists(AededUIPetFrame.unit) ) then
		if ( AededUIPetFrame.unit == "player" ) then
			UnitPopup_ShowMenu(AededUIPetFrameDropDown, "SELF", "player");
		else
			if ( UnitIsUnit("pet", "vehicle") ) then
				UnitPopup_ShowMenu(AededUIPetFrameDropDown, "VEHICLE", "vehicle");
			else
				UnitPopup_ShowMenu(AededUIPetFrameDropDown, "PET", "pet");
			end
		end
	end
end

function AededUIPetCastingBarFrame_OnLoad (self)
	CastingBarFrame_OnLoad(self, "pet", false, false);

	self:RegisterEvent("UNIT_PET");

	self.showCastbar = UnitIsPossessed("pet");
end

function AededUIPetCastingBarFrame_OnEvent (self, event, ...)
	local arg1 = ...;
	if ( event == "UNIT_PET" ) then
		if ( arg1 == "player" ) then
			self.showCastbar = UnitIsPossessed("pet");

			if ( not self.showCastbar ) then
				self:Hide();
			elseif ( self.casting or self.channeling ) then
				self:Show();
			end
		end
		return;
	end
	AededUICastingBarFrame_OnEvent(self, event, ...);
end
