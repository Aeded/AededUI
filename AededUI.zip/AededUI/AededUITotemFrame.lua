
function AededUITotemFrame_OnLoad(self)
	self:RegisterEvent("PLAYER_TOTEM_UPDATE");
	self:RegisterEvent("PLAYER_ENTERING_WORLD");

	AededUITotemFrame_Update();
end

function AededUITotemFrame_Update()
	if ( AededUIPetFrame and AededUIPetFrame:IsShown() ) then
		AededUITotemFrame:Hide();
		return;
	end

	local haveTotem, name, startTime, duration, icon;
	local slot;
	local button;
	AededUITotemFrame.activeTotems = 0;
	for i=1, MAX_TOTEMS do
		slot = TOTEM_PRIORITIES[i];
		haveTotem, name, startTime, duration, icon = GetTotemInfo(slot);
		if ( haveTotem ) then
			button = _G["AededUITotemFrameTotem"..i];
			button.slot = slot;
			AededUITotemButton_Update(button, startTime, duration, icon);
		

			if ( button:IsShown() ) then
				AededUITotemFrame.activeTotems = AededUITotemFrame.activeTotems + 1;
			end
		else
			button = _G["AededUITotemFrameTotem"..i];
			button.slot = 0;

			button:Hide();
		end
	end
	if ( AededUITotemFrame.activeTotems > 0 ) then
		AededUITotemFrame:Show();
	else
		AededUITotemFrame:Hide();
	end
end

function AededUITotemFrame_OnEvent(self, event, ...)
	if ( event == "PLAYER_ENTERING_WORLD" ) then
		AededUITotemFrame_Update();
	elseif ( event == "PLAYER_TOTEM_UPDATE" ) then
		local slot = ...;
		local haveTotem, name, startTime, duration, icon = GetTotemInfo(slot);
		local button;
		for i=1, MAX_TOTEMS do
			button = _G["AededUITotemFrameTotem"..i];
			if ( button.slot == slot ) then
				local previouslyShown = button:IsShown();
				AededUITotemButton_Update(button, startTime, duration, icon);
				-- check to see if we should be showing or hiding the parent frame
				if ( previouslyShown ) then
					if ( not button:IsShown() ) then
						AededUITotemFrame.activeTotems = AededUITotemFrame.activeTotems - 1;
					end
				else
					if ( button:IsShown() ) then
						AededUITotemFrame.activeTotems = AededUITotemFrame.activeTotems + 1;
					end
				end
				if ( AededUITotemFrame.activeTotems > 0 ) then
					AededUITotemFrame:Show();
				else
					AededUITotemFrame:Hide();
				end
				return;
			end
		end

		-- The assumption is that we have gained a AededUITotem that we did not previously have
		-- so the AededUITotem buttons have to be reordered. It's easier to just do a full update
		-- rather than sorting the buttons since there aren't that many.
		AededUITotemFrame_Update();
	end
end

function AededUITotemButton_OnClick(self, mouseButton)
	if ( mouseButton == "RightButton" ) then
		DestroyTotem(self.slot);
	end
end

function AededUITotemButton_OnUpdate(button, elapsed)
	if ( GameTooltip:IsOwned(button) ) then
		GameTooltip:SetTotem(button.slot);
	end
end

function AededUITotemButton_Update(button, startTime, duration, icon)
	local buttonName = button:GetName();
	local buttonIcon = _G[buttonName.."IconTexture"];
	local buttonCooldown = _G[buttonName.."IconCooldown"];

	if ( duration > 0 ) then
		buttonIcon:SetTexture(icon);
		buttonIcon:Show();
		CooldownFrame_Set(buttonCooldown, startTime, duration, 1);
		buttonCooldown:Show();
		button:SetScript("OnUpdate", AededUITotemButton_OnUpdate);
		button:Show();
	else
		buttonIcon:Hide();
		buttonCooldown:Hide();
		button:SetScript("OnUpdate", nil);
		button:Hide();
	end
end
