-- UI Fix
hooksecurefunc("ActionButton_ShowGrid", function(Button)
   if not Button then
      Button = this
   end
   _G[Button:GetName().."NormalTexture"]:SetVertexColor(1, 1, 1, 1)
end)


hooksecurefunc("TotemButton_OnUpdate", function()


	TotemFrameTotem1Duration:Hide()
	TotemFrameTotem2Duration:Hide()
	TotemFrameTotem3Duration:Hide()
	TotemFrameTotem4Duration:Hide()
 
end)




hooksecurefunc("TargetFrame_CheckFaction", function(self)
	if ( not UnitPlayerControlled(self.unit) and UnitIsTapDenied(self.unit) ) then
		self.nameBackground:SetVertexColor(0, 0, 0, 0.5);
		if ( self.portrait ) then
			self.portrait:SetVertexColor(0.5, 0.5, 0.5);
		end
	else
		self.nameBackground:SetVertexColor(0, 0, 0, 0.5);
		if ( self.portrait ) then
			self.portrait:SetVertexColor(1.0, 1.0, 1.0);
		end
	end

	if ( self.showPVP ) then
		local factionGroup = UnitFactionGroup(self.unit);
		if ( UnitIsPVPFreeForAll(self.unit) ) then
				self.prestigePortrait:Hide();
				self.prestigeBadge:Hide();
				self.pvpIcon:SetTexture("Interface\\TargetingFrame\\UI-PVP-FFA");
				self.pvpIcon:Hide();
		elseif ( factionGroup and factionGroup ~= "Neutral" and UnitIsPVP(self.unit) ) then
				self.prestigePortrait:Hide();
				self.prestigeBadge:Hide();
				self.pvpIcon:SetTexture("Interface\\TargetingFrame\\UI-PVP-"..factionGroup);
				self.pvpIcon:Hide();
		else
			self.prestigePortrait:Hide();
			self.prestigeBadge:Hide();
			self.pvpIcon:Hide();
		end
	end
end)
----------------------------------------------------------------------------------------------------
--random
----------------------------------------------------------------------------------------------------
ExhaustionTick:Hide()
ExhaustionTickNormal:Hide()
ExhaustionTickHighlight:Hide()

MinimapZoomIn:Hide()
MinimapZoomOut:Hide()
MinimapZoneText:Hide()
MinimapZoneTextButton:Hide()
MinimapBorderTop:Hide()
MinimapToggleButton:Hide()
MiniMapWorldMapButton:Hide()
GameTimeFrame:Hide()

MinimapCluster:SetScale(0.95)
MinimapCluster:ClearAllPoints()
MinimapCluster:SetPoint("TOPRIGHT", "UIParent", "TOPRIGHT", 10, -20);


-----------------------------------------------------------------------------------------------------
--Error messages
-----------------------------------------------------------------------------------------------------


local event = CreateFrame"Frame"
local dummy = function() end


UIErrorsFrame:UnregisterEvent"UI_ERROR_MESSAGE"
event.UI_ERROR_MESSAGE = function(self, event, error)
	if(not stuff[error]) then
		UIErrorsFrame:AddMessage(error, 1, .1, .1)
	end
end
	
event:RegisterEvent"UI_ERROR_MESSAGE"




----------------------------------------------------------------------------------------------------
--Frames scale
----------------------------------------------------------------------------------------------------
--SetCVar("UIScale", 0.675)




WorldMapFrame.ScrollContainer.GetCursorPosition = function(f)
   local x,y = MapCanvasScrollControllerMixin.GetCursorPosition(f);
   local s = WorldMapFrame:GetScale();
   return x/s, y/s;
end

WorldMapFrame:SetScale(0.8)
WorldMapFrame.BlackoutFrame.Blackout:SetAlpha(0)
WorldMapFrame.BlackoutFrame:EnableMouse(false)

WorldMapFrame:SetMovable(true)
WorldMapFrame:EnableMouse(true)
WorldMapFrame:RegisterForDrag("LeftButton")
WorldMapFrame:SetScript("OnDragStart", WorldMapFrame.StartMoving)
WorldMapFrame:SetScript("OnDragStop", WorldMapFrame.StopMovingOrSizing)


TargetFrameTextureFrameName:SetFont("Fonts\\FRIZQT__.TTF", 10)
TargetFrameToTTextureFrameName:SetFont("Fonts\\FRIZQT__.TTF", 8.75)


TargetFrame:SetScale(1.35);
TargetFrameTextureFrame.HealthBarText:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
TargetFrameTextureFrame.ManaBarText:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
TargetFrameSpellBar:SetScale(0.9)


TargetFrameToT:SetScale(0.675);
TargetFrameToT:ClearAllPoints();
TargetFrameToT:SetPoint("BOTTOMRIGHT", TargetFrame, 15, 0)


FocusFrame:SetScale(0.89);
FocusFrameTextureFrame.HealthBarText:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
FocusFrameTextureFrame.ManaBarText:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
FocusFrameSpellBar:SetScale(0.85)


FocusFrameToT:SetScale(0.75)
FocusFrameToT:ClearAllPoints()
FocusFrameToT:SetPoint("BOTTOMRIGHT", FocusFrame,-8.5,-15)

ComboFrame:SetScale(1.3);
ComboFrame:ClearAllPoints();
ComboFrame:SetPoint("TOPRIGHT", "TargetFrame", "TOPRIGHT", -46.5, -7.5);



--beter way with XML
for i=1, MAX_PARTY_MEMBERS do

	local frame = _G["AededUIPartyMemberFrame"..i]
	local frameName = _G["AededUIPartyMemberFrame"..i.."Name"]
	local petFrame = _G["AededUIPartyMemberFrame"..i.."PetFrame"]
	if ( i < 3 ) then
		frame:SetScale(1.5);
		petFrame:SetScale(0.85);
		frameName:SetFont("Fonts\\FRIZQT__.TTF", 8.3)
	else
		frame:SetScale(1);
		frameName:SetFont("Fonts\\FRIZQT__.TTF", 10)
	end
	
end

local hideTable = {
	PartyMemberFrame1,
	PartyMemberFrame2,
	PartyMemberFrame3,
	PartyMemberFrame4,
	CastingBarFrame,
	UIWidgetTopCenterContainerFrame,
	PlayerFrame,
	PetFrame,
	TargetFrame,
	FocusFrame,
	
}
local BlizzardHide = CreateFrame("Frame")
BlizzardHide:Hide()
BlizzardHide:SetAllPoints()
for _,v in ipairs(hideTable) do
    v:SetParent(BlizzardHide)
end

----------------------------------------------------------------------------------------------------
--dd
----------------------------------------------------------------------------------------------------



hooksecurefunc("TargetofTargetHealthCheck", function(self)
	if ( UnitIsPlayer(self.unit) ) then
		if ( UnitIsDead(self.unit) ) then
			self.portrait:SetVertexColor(0.35, 0.35, 0.35, 1.0);
		elseif ( UnitIsGhost(self.unit) ) then
			self.portrait:SetVertexColor(0.2, 0.2, 0.75, 1.0);
		else
			self.portrait:SetVertexColor(1.0, 1.0, 1.0, 1.0);
		end
	else
		self.portrait:SetVertexColor(1.0, 1.0, 1.0, 1.0);
	end
end)

hooksecurefunc("TargetHealthCheck", function(self)
	if ( UnitIsPlayer(self.unit) ) then
		local parent = self:GetParent();
		if ( parent.portrait ) then
			if ( UnitIsDead(self.unit) ) then
				parent.portrait:SetVertexColor(0.35, 0.35, 0.35, 1.0);
			elseif ( UnitIsGhost(self.unit) ) then
				parent.portrait:SetVertexColor(0.2, 0.2, 0.75, 1.0);
			else
				parent.portrait:SetVertexColor(1.0, 1.0, 1.0, 1.0);
			end
		end
	end
end)


hooksecurefunc("TargetFrame_HealthUpdate", function(self, elapsed, unit)
	if ( UnitIsPlayer(unit) ) then
		if ( self.portrait ) then
			self.portrait:SetAlpha(1);
		end
	end
end)





